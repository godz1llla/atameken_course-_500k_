<?php $title = __('admin.manage_enrollments'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>📝 <?php echo __('admin.manage_enrollments'); ?></h1>
    </div>
    
    <div class="enroll-form">
        <h3>➕ <?php echo __('admin.enroll_student'); ?></h3>
        <form method="POST" action="/index.php?url=admin/enrollStudent">
            <div class="form-row">
                <select name="user_id" required>
                    <option value=""><?php echo __('common.select'); ?> <?php echo __('dashboard.students'); ?></option>
                    <?php foreach ($students as $student): ?>
                    <option value="<?php echo $student['id']; ?>">
                        👤 <?php echo $student['first_name'] . ' ' . $student['last_name']; ?> (<?php echo $student['email']; ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="course_id" required>
                    <option value=""><?php echo __('common.select'); ?> <?php echo __('nav.courses'); ?></option>
                    <?php foreach ($courses as $course): ?>
                    <option value="<?php echo $course['id']; ?>">
                        📚 <?php echo $course['title']; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                
                <button type="submit" class="btn btn-primary">✅ <?php echo __('admin.enroll'); ?></button>
            </div>
        </form>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>
