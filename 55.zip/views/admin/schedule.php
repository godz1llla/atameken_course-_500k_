<?php $title = __('admin.class_schedule'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h1>📅 <?php echo __('admin.class_schedule'); ?></h1>
    </div>
    
    <div class="card">
        <div id="calendar"></div>
    </div>
</div>

<!-- Модальное окно для добавления занятия -->
<div id="scheduleModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h2>➕ <?php echo __('admin.add_class'); ?></h2>
            <span class="modal-close" onclick="closeScheduleModal()">&times;</span>
        </div>
        <form id="scheduleForm" class="form">
            <div class="form-group">
                <label><?php echo __('admin.select_group'); ?></label>
                <select name="group_id" id="form_group_id" required>
                    <option value=""><?php echo __('admin.select_group'); ?></option>
                    <?php foreach ($groups as $group): ?>
                        <option value="<?php echo $group['id']; ?>">
                            <?php echo htmlspecialchars($group['name']); ?> 
                            <?php if (!empty($group['course_title'])): ?>
                                - <?php echo htmlspecialchars($group['course_title']); ?>
                            <?php endif; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label><?php echo __('admin.class_title'); ?> (<?php echo __('common.optional'); ?>)</label>
                <input type="text" name="title" id="form_title" placeholder="<?php echo __('admin.class_title_placeholder'); ?>">
            </div>
            
            <div class="form-group">
                <label><?php echo __('admin.start_time'); ?></label>
                <input type="datetime-local" name="start_time" id="form_start_time" required>
            </div>
            
            <div class="form-group">
                <label><?php echo __('admin.end_time'); ?></label>
                <input type="datetime-local" name="end_time" id="form_end_time" required>
            </div>
            
            <div class="form-group">
                <label><?php echo __('admin.location'); ?></label>
                <input type="text" name="location" id="form_location" placeholder="<?php echo __('admin.location_placeholder'); ?>">
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">💾 <?php echo __('admin.save_class'); ?></button>
                <button type="button" class="btn btn-outline" onclick="closeScheduleModal()">❌ <?php echo __('common.cancel'); ?></button>
            </div>
        </form>
    </div>
</div>

<style>
#calendar {
    padding: 20px;
    min-height: 600px;
}

/* Modal Styles */
.modal {
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-content {
    background: var(--white);
    border-radius: var(--radius);
    box-shadow: var(--shadow-lg);
    width: 90%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    animation: modalSlideIn 0.3s ease;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(-50px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 25px 30px;
    border-bottom: 1px solid var(--light-gray);
}

.modal-header h2 {
    margin: 0;
    font-size: 24px;
    font-weight: 700;
    color: var(--dark);
}

.modal-close {
    font-size: 32px;
    font-weight: 300;
    color: var(--gray);
    cursor: pointer;
    line-height: 1;
    transition: var(--transition);
}

.modal-close:hover {
    color: var(--dark);
}

.modal-content .form {
    padding: 30px;
    margin: 0;
    box-shadow: none;
}

/* FullCalendar Customization */
.fc {
    font-family: inherit;
}

.fc-header-toolbar {
    margin-bottom: 20px;
}

.fc-button {
    background: var(--primary) !important;
    border: none !important;
    padding: 8px 16px !important;
    border-radius: var(--radius) !important;
    font-weight: 600 !important;
    transition: var(--transition) !important;
}

.fc-button:hover {
    background: var(--primary-dark) !important;
    transform: translateY(-2px) !important;
}

.fc-button-primary:not(:disabled).fc-button-active {
    background: var(--primary-dark) !important;
}

.fc-event {
    border: none !important;
    border-radius: 6px !important;
    padding: 4px 8px !important;
    cursor: pointer !important;
}

.fc-daygrid-event {
    border-radius: 6px !important;
}

.fc-day-today {
    background-color: rgba(115, 103, 240, 0.05) !important;
}

.fc-col-header-cell {
    background: var(--light-gray) !important;
    padding: 10px !important;
    font-weight: 600 !important;
}

.fc-daygrid-day {
    background: var(--white) !important;
}

@media (max-width: 768px) {
    .modal-content {
        width: 95%;
        margin: 20px;
    }
    
    .modal-header {
        padding: 20px;
    }
    
    .modal-content .form {
        padding: 20px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    let selectedDate = null;
    let selectedStartTime = null;
    
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        // locale will use browser default, can be set if locale files are loaded
        firstDay: 1,
        height: 'auto',
        events: function(fetchInfo, successCallback, failureCallback) {
            fetch('/index.php?url=admin/getScheduleEvents')
                .then(response => response.json())
                .then(data => {
                    successCallback(data);
                })
                .catch(error => {
                    console.error('Error loading events:', error);
                    failureCallback(error);
                });
        },
        dateClick: function(info) {
            selectedDate = info.dateStr;
            selectedStartTime = null;
            openScheduleModal(info.dateStr);
        },
        eventClick: function(info) {
            // Можно добавить редактирование при клике на событие
            console.log('Event clicked:', info.event);
        },
        selectable: true,
        select: function(info) {
            selectedStartTime = info.startStr;
            openScheduleModal(null, info.startStr, info.endStr);
        }
    });
    
    calendar.render();
    
    // Открытие модального окна
    function openScheduleModal(dateStr, startStr, endStr) {
        const modal = document.getElementById('scheduleModal');
        const form = document.getElementById('scheduleForm');
        
        // Очистка формы
        form.reset();
        
        // Заполнение дат
        if (dateStr) {
            // Если кликнули на день без времени
            const date = new Date(dateStr + 'T09:00:00');
            const endDate = new Date(date);
            endDate.setHours(date.getHours() + 2);
            
            document.getElementById('form_start_time').value = formatDateTimeLocal(date);
            document.getElementById('form_end_time').value = formatDateTimeLocal(endDate);
        } else if (startStr && endStr) {
            // Если выбрали временной диапазон
            document.getElementById('form_start_time').value = formatDateTimeLocal(new Date(startStr));
            document.getElementById('form_end_time').value = formatDateTimeLocal(new Date(endStr));
        }
        
        modal.style.display = 'flex';
    }
    
    // Закрытие модального окна
    window.closeScheduleModal = function() {
        document.getElementById('scheduleModal').style.display = 'none';
        document.getElementById('scheduleForm').reset();
    };
    
    // Обработка отправки формы
    document.getElementById('scheduleForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const data = Object.fromEntries(formData.entries());
        
        fetch('/index.php?url=admin/addScheduleEvent', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams(data).toString()
        })
        .then(response => response.json())
        .then(result => {
            if (result.status === 'success') {
                // Добавляем новое событие в календарь
                calendar.addEvent(result.event);
                closeScheduleModal();
                
                // Показываем уведомление об успехе (можно добавить toast)
                alert('<?php echo __('admin.class_added_success'); ?>');
            } else {
                alert('<?php echo __('admin.error'); ?>: ' + (result.message || '<?php echo __('admin.unknown_error'); ?>'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('<?php echo __('admin.error'); ?>: <?php echo __('admin.unknown_error'); ?>');
        });
    });
    
    // Закрытие модального окна при клике вне его
    document.getElementById('scheduleModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeScheduleModal();
        }
    });
    
    // Функция форматирования даты для input datetime-local
    function formatDateTimeLocal(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    }
});
</script>

<?php include 'views/layouts/footer.php'; ?>

