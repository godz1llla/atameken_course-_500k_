<?php $title = __('course.manage') . ': ' . $course['title']; include 'views/layouts/header.php'; ?>

<div class="container">
    <h1>⚙️ <?php echo __('course.manage'); ?>: <?php echo $course['title']; ?></h1>
    
    <!-- Weekly Tests Section -->
    <div style="background: rgba(255, 255, 255, 0.98); padding: 35px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); margin-bottom: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
            <h2>📅 <?php echo __('admin.weekly_tests'); ?></h2>
            <a href="/index.php?url=test/createWeeklyTest/<?php echo $course['id']; ?>" class="btn btn-success">➕ <?php echo __('admin.create_weekly_test'); ?></a>
        </div>
        
        <?php if (!empty($weekly_tests)): ?>
            <div style="display: grid; gap: 15px;">
                <?php foreach ($weekly_tests as $wTest): ?>
                <div style="padding: 20px; background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); border-radius: 12px; border-left: 5px solid var(--primary);">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h4 style="font-weight: 800; margin-bottom: 8px;">
                                📅 <?php echo __('admin.week'); ?> <?php echo $wTest['week_number']; ?>: <?php echo $wTest['title']; ?>
                                <?php if ($wTest['is_mandatory']): ?>
                                    <span style="background: #fef3c7; color: #92400e; padding: 4px 12px; border-radius: 50px; font-size: 11px; margin-left: 10px;">⚠️ <?php echo __('admin.mandatory'); ?></span>
                                <?php endif; ?>
                            </h4>
                            <p style="color: #6b7280; font-size: 14px;"><?php echo $wTest['description']; ?></p>
                            <p style="font-size: 13px; color: #6b7280; margin-top: 8px;">
                                💯 <?php echo __('test.passing_score'); ?>: <?php echo $wTest['passing_score']; ?>% 
                                <?php if ($wTest['time_limit']): ?>
                                    | ⏱ <?php echo $wTest['time_limit']; ?> <?php echo __('time.minutes'); ?>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="color: #6b7280; text-align: center; padding: 30px;"><?php echo __('admin.no_weekly_tests'); ?></p>
        <?php endif; ?>
    </div>
    
    <div class="course-structure">
        <div class="add-module-form">
            <h3>➕ <?php echo __('admin.add_module'); ?></h3>
            <form method="POST" action="/index.php?url=admin/createModule/<?php echo $course['id']; ?>">
                <input type="text" name="title" placeholder="<?php echo __('course.title'); ?>" required>
                <textarea name="description" placeholder="<?php echo __('course.description'); ?>"></textarea>
                <input type="number" name="order_num" placeholder="Order" value="0">
                <button type="submit" class="btn btn-primary">➕ <?php echo __('admin.add_module'); ?></button>
            </form>
        </div>
        
        <?php foreach ($modules as $module): ?>
        <div class="module-block">
            <div class="module-header">
                <h3>📂 <?php echo $module['title']; ?></h3>
                <a href="/index.php?url=admin/deleteModule/<?php echo $module['id']; ?>" class="btn btn-danger btn-small" onclick="return confirm('<?php echo __('admin.delete_module'); ?>?')">
                    🗑️ <?php echo __('admin.delete_module'); ?>
                </a>
            </div>
            
            <p><?php echo $module['description']; ?></p>
            
            <div class="lessons-list">
                <?php if (!empty($module['lessons'])): ?>
                    <?php foreach ($module['lessons'] as $lesson): ?>
                    <div class="lesson-item">
                        <span>📄 <?php echo $lesson['title']; ?></span>
                        <div class="actions">
                            <?php if (Session::getUserRole() === 'teacher'): ?>
                                <a href="/index.php?url=teacher/createHomework/<?php echo $lesson['id']; ?>" class="btn btn-small btn-success">📝 <?php echo __('teacher.create_homework'); ?></a>
                                <?php if (!empty($lessonsWithHomeworks[$lesson['id']])): ?>
                                    <?php foreach ($lessonsWithHomeworks[$lesson['id']] as $hw): ?>
                                        <a href="/index.php?url=teacher/viewSubmissions/<?php echo $hw['id']; ?>" class="btn btn-small btn-info" title="<?php echo htmlspecialchars($hw['title']); ?>">📋 <?php echo __('teacher.homework'); ?> (<?php echo $hw['submissions_count']; ?>)</a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <a href="/index.php?url=admin/editLesson/<?php echo $lesson['id']; ?>" class="btn btn-small">📝 <?php echo __('common.edit'); ?></a>
                            <a href="/index.php?url=admin/deleteLesson/<?php echo $lesson['id']; ?>" class="btn btn-danger btn-small" onclick="return confirm('<?php echo __('common.confirm_delete'); ?>')">🗑️</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div class="add-lesson-form">
                <h4>➕ <?php echo __('admin.add_lesson'); ?></h4>
                <form method="POST" action="/index.php?url=admin/createLesson/<?php echo $module['id']; ?>">
                    <input type="text" name="title" placeholder="<?php echo __('course.title'); ?>" required>
                    <textarea name="content" placeholder="<?php echo __('course.description'); ?>"></textarea>
                    <input type="text" name="video_url" placeholder="YouTube URL">
                    <input type="number" name="order_num" placeholder="Order" value="0">
                    <button type="submit" class="btn btn-primary">➕ <?php echo __('admin.add_lesson'); ?></button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <a href="/index.php?url=admin/courses" class="btn btn-secondary" style="margin-top: 30px;">
        ← <?php echo __('common.back'); ?> to <?php echo __('nav.courses'); ?>
    </a>
</div>

<?php include 'views/layouts/footer.php'; ?>
