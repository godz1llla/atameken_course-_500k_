<?php $title = isset($course) ? __('common.edit') . ' ' . __('nav.courses') : __('admin.create_course'); include 'views/layouts/header.php'; ?>

<div class="container">
    <h1><?php echo isset($course) ? '📝 ' . __('common.edit') . ' ' . __('nav.courses') : '➕ ' . __('admin.create_course'); ?></h1>
    
    <form method="POST" enctype="multipart/form-data" class="form">
        <div class="form-group">
            <label>📖 <?php echo __('course.title'); ?></label>
            <input type="text" name="title" value="<?php echo $course['title'] ?? ''; ?>" required>
        </div>
        
        <div class="form-group">
            <label>📝 <?php echo __('course.description'); ?></label>
            <textarea name="description" rows="5" required><?php echo $course['description'] ?? ''; ?></textarea>
        </div>
        
        <div class="form-group">
            <label>👨‍🏫 <?php echo __('course.teacher'); ?></label>
            <select name="teacher_id" required>
                <option value=""><?php echo __('common.select'); ?> <?php echo __('course.teacher'); ?></option>
                <?php foreach ($teachers as $teacher): ?>
                <option value="<?php echo $teacher['id']; ?>" <?php echo (isset($course) && $course['teacher_id'] == $teacher['id']) ? 'selected' : ''; ?>>
                    <?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label>🖼️ <?php echo __('course.image'); ?></label>
            <input type="file" name="image" accept="image/*">
            <?php if (isset($course) && $course['image']): ?>
                <img src="/public/uploads/<?php echo $course['image']; ?>" alt="Course Image" style="max-width: 200px; margin-top: 10px; border-radius: 8px;">
            <?php endif; ?>
        </div>
        
        <div class="form-group">
            <label>
                <input type="checkbox" name="is_published" <?php echo (isset($course) && $course['is_published']) ? 'checked' : ''; ?>>
                ✅ <?php echo __('course.published'); ?>
            </label>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">💾 <?php echo __('common.save'); ?></button>
            <a href="/index.php?url=admin/courses" class="btn btn-secondary">❌ <?php echo __('common.cancel'); ?></a>
        </div>
    </form>
</div>

<?php include 'views/layouts/footer.php'; ?>
