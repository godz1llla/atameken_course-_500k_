<?php $title = __('student.my_schedule'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h1>📅 <?php echo __('student.my_schedule'); ?></h1>
    </div>
    
    <div class="card">
        <div id="calendar"></div>
    </div>
</div>

<!-- Модальное окно с деталями занятия -->
<div id="scheduleModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h2>📋 <?php echo __('student.class_details'); ?></h2>
            <span class="modal-close" onclick="closeScheduleModal()">&times;</span>
        </div>
        <div class="modal-body" id="modalBody">
            <div style="text-align: center; padding: 40px;">
                <div class="spinner" style="border: 4px solid var(--light-gray); border-top: 4px solid var(--primary); border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 0 auto;"></div>
                <p style="margin-top: 15px; color: var(--gray);"><?php echo __('common.loading'); ?>...</p>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline" onclick="closeScheduleModal()">❌ <?php echo __('common.close'); ?></button>
        </div>
    </div>
</div>

<style>
#calendar {
    padding: 20px;
    min-height: 600px;
}

/* Modal Styles */
.modal {
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-content {
    background: var(--white);
    border-radius: var(--radius);
    box-shadow: var(--shadow-lg);
    width: 90%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    animation: modalSlideIn 0.3s ease;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(-50px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 25px 30px;
    border-bottom: 1px solid var(--light-gray);
}

.modal-header h2 {
    margin: 0;
    font-size: 24px;
    font-weight: 700;
    color: var(--dark);
}

.modal-close {
    font-size: 32px;
    font-weight: 300;
    color: var(--gray);
    cursor: pointer;
    line-height: 1;
    transition: var(--transition);
}

.modal-close:hover {
    color: var(--dark);
}

.modal-body {
    padding: 30px;
}

.modal-footer {
    padding: 20px 30px;
    border-top: 1px solid var(--light-gray);
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.class-details {
    display: grid;
    gap: 20px;
}

.detail-item {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.detail-label {
    font-size: 14px;
    font-weight: 600;
    color: var(--gray);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.detail-value {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark);
}

.badge {
    display: inline-block;
    padding: 6px 12px;
    border-radius: var(--radius);
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.badge-success {
    background: rgba(16, 185, 129, 0.1);
    color: var(--success);
    border: 1px solid var(--success);
}

.badge-danger {
    background: rgba(234, 84, 85, 0.1);
    color: var(--danger);
    border: 1px solid var(--danger);
}

.badge-warning {
    background: rgba(255, 159, 67, 0.1);
    color: var(--warning);
    border: 1px solid var(--warning);
}

.badge-default {
    background: rgba(110, 107, 123, 0.1);
    color: var(--gray);
    border: 1px solid var(--gray);
}

/* FullCalendar Customization */
.fc {
    font-family: inherit;
}

.fc-header-toolbar {
    margin-bottom: 20px;
}

.fc-button {
    background: var(--primary) !important;
    border: none !important;
    padding: 8px 16px !important;
    border-radius: var(--radius) !important;
    font-weight: 600 !important;
    transition: var(--transition) !important;
}

.fc-button:hover {
    background: var(--primary-dark) !important;
    transform: translateY(-2px) !important;
}

.fc-button-primary:not(:disabled).fc-button-active {
    background: var(--primary-dark) !important;
}

.fc-event {
    border: none !important;
    border-radius: 6px !important;
    padding: 4px 8px !important;
    cursor: pointer !important;
}

.fc-daygrid-event {
    border-radius: 6px !important;
}

.fc-day-today {
    background-color: rgba(115, 103, 240, 0.05) !important;
}

.fc-col-header-cell {
    background: var(--light-gray) !important;
    padding: 10px !important;
    font-weight: 600 !important;
}

.fc-daygrid-day {
    background: var(--white) !important;
}

@media (max-width: 768px) {
    #calendar {
        padding: 10px;
    }
    
    .modal-content {
        width: 95%;
        margin: 20px;
    }
    
    .modal-header {
        padding: 20px;
    }
    
    .modal-body {
        padding: 20px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        firstDay: 1,
        height: 'auto',
        events: function(fetchInfo, successCallback, failureCallback) {
            fetch('/index.php?url=student/getMyScheduleEvents')
                .then(response => response.json())
                .then(data => {
                    successCallback(data);
                })
                .catch(error => {
                    console.error('Error loading events:', error);
                    failureCallback(error);
                });
        },
        eventClick: function(info) {
            // Открываем модальное окно с деталями занятия
            openScheduleModal(info.event);
        },
        dateClick: function(info) {
            // Не делаем ничего при клике на день (только просмотр)
            console.log('Date clicked:', info.dateStr);
        }
    });
    
    calendar.render();
    
    // Открытие модального окна с деталями занятия
    function openScheduleModal(event) {
        const modal = document.getElementById('scheduleModal');
        const modalBody = document.getElementById('modalBody');
        
        // Показываем модальное окно с загрузкой
        modal.style.display = 'flex';
        modalBody.innerHTML = `
            <div style="text-align: center; padding: 40px;">
                <div class="spinner" style="border: 4px solid var(--light-gray); border-top: 4px solid var(--primary); border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 0 auto;"></div>
                <p style="margin-top: 15px; color: var(--gray);"><?php echo __('common.loading'); ?>...</p>
            </div>
        `;
        
        // Загружаем статус посещаемости
        fetch('/index.php?url=student/getAttendanceStatus/' + event.id)
            .then(response => response.json())
            .then(attendanceData => {
                // Получаем данные из события (extendedProps содержит дополнительные данные)
                const scheduleData = {
                    scheduleTitle: event.extendedProps.scheduleTitle || '',
                    groupName: event.extendedProps.groupName || '',
                    courseTitle: event.extendedProps.courseTitle || '',
                    teacherName: event.extendedProps.teacherName || '',
                    location: event.extendedProps.location || ''
                };
                
                // Формируем HTML с деталями занятия
                let statusBadge = '';
                if (attendanceData.hasStatus && attendanceData.status) {
                    let badgeClass = 'badge-default';
                    let statusText = '<?php echo __('teacher.unknown_status'); ?>';
                    
                    if (attendanceData.status === 'present') {
                        badgeClass = 'badge-success';
                        statusText = '✅ <?php echo __('teacher.present'); ?>';
                    } else if (attendanceData.status === 'absent') {
                        badgeClass = 'badge-danger';
                        statusText = '❌ <?php echo __('teacher.absent'); ?>';
                    } else if (attendanceData.status === 'late') {
                        badgeClass = 'badge-warning';
                        statusText = '⏰ <?php echo __('teacher.late'); ?>';
                    }
                    
                    statusBadge = `
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('teacher.attendance_status'); ?></span>
                            <span class="badge ${badgeClass}">${statusText}</span>
                        </div>
                    `;
                } else {
                    statusBadge = `
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('teacher.attendance_status'); ?></span>
                            <span class="badge badge-default"><?php echo __('student.not_marked'); ?></span>
                        </div>
                    `;
                }
                
                // Форматируем дату и время
                const startDate = new Date(event.start);
                const endDate = new Date(event.end);
                const formattedStart = formatDateTime(startDate);
                const formattedEnd = formatDateTime(endDate);
                
                modalBody.innerHTML = `
                    <div class="class-details">
                        ${scheduleData.scheduleTitle ? `
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('admin.class_title'); ?></span>
                            <span class="detail-value">${scheduleData.scheduleTitle}</span>
                        </div>
                        ` : ''}
                        
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('admin.group_name'); ?></span>
                            <span class="detail-value">${scheduleData.groupName || '-'}</span>
                        </div>
                        
                        ${scheduleData.courseTitle ? `
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('course.title'); ?></span>
                            <span class="detail-value">${scheduleData.courseTitle}</span>
                        </div>
                        ` : ''}
                        
                        ${scheduleData.teacherName ? `
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('course.teacher'); ?></span>
                            <span class="detail-value">${scheduleData.teacherName}</span>
                        </div>
                        ` : ''}
                        
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('admin.start_time'); ?></span>
                            <span class="detail-value">${formattedStart}</span>
                        </div>
                        
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('admin.end_time'); ?></span>
                            <span class="detail-value">${formattedEnd}</span>
                        </div>
                        
                        ${scheduleData.location ? `
                        <div class="detail-item">
                            <span class="detail-label"><?php echo __('admin.location'); ?></span>
                            <span class="detail-value">${scheduleData.location}</span>
                        </div>
                        ` : ''}
                        
                        ${statusBadge}
                    </div>
                `;
            })
            .catch(error => {
                console.error('Error loading attendance:', error);
                modalBody.innerHTML = `
                    <div style="text-align: center; padding: 40px;">
                        <div style="font-size: 48px; margin-bottom: 15px;">⚠️</div>
                        <p style="color: var(--danger);"><?php echo __('student.error_loading_details'); ?></p>
                    </div>
                `;
            });
    }
    
    // Закрытие модального окна
    window.closeScheduleModal = function() {
        document.getElementById('scheduleModal').style.display = 'none';
    };
    
    // Закрытие модального окна при клике вне его
    document.getElementById('scheduleModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeScheduleModal();
        }
    });
    
    // Функция форматирования даты и времени
    function formatDateTime(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        
        return `${day}.${month}.${year} ${hours}:${minutes}`;
    }
});
</script>

<?php include 'views/layouts/footer.php'; ?>

