<?php $title = __('achievements.title'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>🏆 <?php echo __('achievements.title'); ?></h1>
    </div>
    
    <div class="achievements-grid">
        <?php foreach ($achievements as $achievement): ?>
        <div class="achievement-card <?php echo $achievement['earned'] ? 'earned' : 'locked'; ?>">
            <?php if ($achievement['icon']): ?>
                <img src="/public/uploads/<?php echo $achievement['icon']; ?>" alt="<?php echo $achievement['title']; ?>">
            <?php else: ?>
                <div style="width: 120px; height: 120px; background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 60px; margin: 0 auto 20px;">🏆</div>
            <?php endif; ?>
            <h3><?php echo $achievement['title']; ?></h3>
            <p><?php echo $achievement['description']; ?></p>
            <?php if ($achievement['earned']): ?>
                <span class="earned-badge">✓ <?php echo __('achievements.earned'); ?></span>
            <?php else: ?>
                <span class="locked-badge">🔒 <?php echo __('achievements.locked'); ?></span>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>
