<?php 
$title = isset($homework) ? __('teacher.edit_homework') : __('teacher.create_homework'); 
include 'views/layouts/header.php'; 
?>

<div class="content-area">
    <div class="page-header">
        <h1><?php echo isset($homework) ? '📝 ' . __('teacher.edit_homework') : '➕ ' . __('teacher.create_homework'); ?></h1>
        <a href="/index.php?url=admin/manageCourse/<?php echo $course['id']; ?>" class="btn btn-outline">← <?php echo __('common.back'); ?></a>
    </div>
    
    <div class="card">
        <div style="margin-bottom: 20px; padding: 15px; background: var(--light-gray); border-radius: var(--radius);">
            <p style="margin: 0;"><strong><?php echo __('course.title'); ?>:</strong> <?php echo htmlspecialchars($course['title']); ?></p>
            <p style="margin: 5px 0 0;"><strong><?php echo __('admin.module'); ?>:</strong> <?php echo htmlspecialchars($module['title']); ?></p>
            <p style="margin: 5px 0 0;"><strong><?php echo __('lesson.title'); ?>:</strong> <?php echo htmlspecialchars($lesson['title']); ?></p>
        </div>
        
        <form method="POST" action="/index.php?url=teacher/saveHomework" class="form" style="margin-top: 30px;">
            <input type="hidden" name="lesson_id" value="<?php echo $lesson['id']; ?>">
            <?php if (isset($homework)): ?>
                <input type="hidden" name="homework_id" value="<?php echo $homework['id']; ?>">
            <?php endif; ?>
            
            <div class="form-group">
                <label><?php echo __('teacher.homework_title'); ?> *</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($homework['title'] ?? ''); ?>" required placeholder="<?php echo __('teacher.homework_title_placeholder'); ?>" maxlength="255">
            </div>
            
            <div class="form-group">
                <label><?php echo __('teacher.homework_description'); ?></label>
                <textarea name="description" rows="6" placeholder="<?php echo __('teacher.homework_description_placeholder'); ?>"><?php echo htmlspecialchars($homework['description'] ?? ''); ?></textarea>
                <small style="color: var(--gray); margin-top: 5px; display: block;"><?php echo __('teacher.homework_description_help'); ?></small>
            </div>
            
            <div class="form-group">
                <label><?php echo __('teacher.due_date'); ?> *</label>
                <input type="datetime-local" name="due_date" value="<?php echo isset($homework) && $homework['due_date'] ? date('Y-m-d\TH:i', strtotime($homework['due_date'])) : ''; ?>" required>
                <small style="color: var(--gray); margin-top: 5px; display: block;"><?php echo __('teacher.due_date_help'); ?></small>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-success">💾 <?php echo __('common.save'); ?></button>
                <a href="/index.php?url=admin/manageCourse/<?php echo $course['id']; ?>" class="btn btn-outline">❌ <?php echo __('common.cancel'); ?></a>
            </div>
        </form>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>

