<?php $title = __('site_name'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <div>
            <h1>👋 <?php echo __('dashboard.welcome'); ?>, <?php echo __('dashboard.teachers'); ?>!</h1>
            <p style="color: #6b7280; margin-top: 10px;"><?php echo __('dashboard.manage_platform'); ?></p>
        </div>
        <?php if ($unread_messages > 0): ?>
        <a href="/index.php?url=teacher/messages" class="btn btn-warning" style="position: relative;">
            💬 <?php echo __('nav.messages'); ?>
            <span style="position: absolute; top: -5px; right: -5px; background: #ef4444; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700;"><?php echo $unread_messages; ?></span>
        </a>
        <?php endif; ?>
    </div>
    
    <h2 style="margin: 30px 0 20px; font-size: 24px; font-weight: 800;">📚 <?php echo __('dashboard.my_courses'); ?></h2>
    
    <?php if (count($courses) > 0): ?>
        <div class="courses-grid">
            <?php foreach ($courses as $course): ?>
            <div class="course-card">
                <?php if ($course['image']): ?>
                    <img src="/public/uploads/<?php echo $course['image']; ?>" alt="<?php echo $course['title']; ?>">
                <?php else: ?>
                    <div style="width: 100%; height: 220px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; font-size: 64px;">📚</div>
                <?php endif; ?>
                <h3><?php echo $course['title']; ?></h3>
                <p><?php echo substr($course['description'], 0, 100); ?>...</p>
                <div class="card-actions">
                    <a href="/index.php?url=admin/manageCourse/<?php echo $course['id']; ?>" class="btn btn-primary">⚙️ <?php echo __('course.manage'); ?></a>
                    <a href="/index.php?url=teacher/courseStudents/<?php echo $course['id']; ?>" class="btn btn-secondary">👥 <?php echo __('teacher.view_students'); ?></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="background: rgba(255, 255, 255, 0.98); padding: 60px; text-align: center; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
            <div style="font-size: 80px; margin-bottom: 20px;">📚</div>
            <h3 style="color: #1f2937; margin-bottom: 15px;"><?php echo __('teacher.no_courses'); ?></h3>
            <p style="color: #6b7280;"><?php echo __('teacher.contact_admin'); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>
