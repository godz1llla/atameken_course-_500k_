<?php $title = __('teacher.course_students'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>👥 <?php echo __('teacher.students'); ?> - <?php echo $course['title']; ?></h1>
        <a href="/index.php?url=teacher/dashboard" class="btn btn-secondary">← <?php echo __('common.back'); ?></a>
    </div>
    
    <?php if (count($students) > 0): ?>
    <table class="data-table">
        <thead>
            <tr>
                <th><?php echo __('auth.first_name'); ?></th>
                <th><?php echo __('auth.email'); ?></th>
                <th><?php echo __('teacher.enrolled'); ?></th>
                <th><?php echo __('course.progress'); ?></th>
                <th><?php echo __('admin.status'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($students as $student): ?>
            <tr>
                <td data-label="<?php echo __('auth.first_name'); ?>"><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></td>
                <td data-label="<?php echo __('auth.email'); ?>"><?php echo $student['email']; ?></td>
                <td data-label="<?php echo __('teacher.enrolled'); ?>"><?php echo date('M d, Y', strtotime($student['enrolled_at'])); ?></td>
                <td data-label="<?php echo __('course.progress'); ?>">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo $student['progress']; ?>%"></div>
                    </div>
                    <?php echo $student['progress']; ?>%
                </td>
                <td data-label="<?php echo __('admin.status'); ?>">
                    <?php if ($student['completed_at']): ?>
                        <span class="status active">✅ <?php echo __('course.completed'); ?></span>
                    <?php else: ?>
                        <span class="status inactive">⏳ <?php echo __('teacher.in_progress'); ?></span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <div style="background: rgba(255, 255, 255, 0.98); padding: 60px; text-align: center; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
            <div style="font-size: 80px; margin-bottom: 20px;">👥</div>
            <h3 style="color: #1f2937; margin-bottom: 15px;"><?php echo __('teacher.no_students'); ?></h3>
            <p style="color: #6b7280;"><?php echo __('teacher.no_students_enrolled'); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>
