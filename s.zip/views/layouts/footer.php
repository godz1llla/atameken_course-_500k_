    <?php if (Session::isLoggedIn()): ?>
            </div> <!-- .content-area -->
        </main> <!-- .main-content -->
    </div> <!-- .app-container -->
    <?php else: ?>
    </div> <!-- .main-container -->
    <?php endif; ?>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> LMS System. All rights reserved.</p>
        </div>
    </footer>
    
    <?php 
    // Условная загрузка FullCalendar только для страницы расписания
    $currentUrl = $_GET['url'] ?? '';
    if (strpos($currentUrl, 'schedule') !== false || (isset($title) && strpos(strtolower($title), 'schedule') !== false)):
    ?>
    <!-- FullCalendar CSS -->
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.min.css' rel='stylesheet' />
    <!-- FullCalendar JS -->
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.min.js'></script>
    <?php endif; ?>
    
    <script src="/public/js/main.js"></script>
    <script>
    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        const appContainer = document.querySelector('.app-container');
        const overlay = document.getElementById('sidebarOverlay');
        if (!sidebar) {
            return;
        }
        
        const isMobile = window.matchMedia('(max-width: 768px)').matches;
        sidebar.classList.toggle('collapsed');
        
        if (isMobile) {
            if (appContainer && appContainer.classList.contains('sidebar-collapsed')) {
                appContainer.classList.remove('sidebar-collapsed');
            }
            if (overlay) {
                overlay.classList.toggle('active', sidebar.classList.contains('collapsed'));
            }
        } else if (appContainer) {
            appContainer.classList.toggle('sidebar-collapsed');
            if (overlay) {
                overlay.classList.remove('active');
            }
        }
    }
    
    // Close sidebar when clicking on overlay (mobile)
    document.addEventListener('DOMContentLoaded', function() {
        const overlay = document.getElementById('sidebarOverlay');
        if (overlay) {
            overlay.addEventListener('click', function() {
                const sidebar = document.querySelector('.sidebar');
                if (sidebar && sidebar.classList.contains('collapsed')) {
                    sidebar.classList.remove('collapsed');
                    overlay.classList.remove('active');
                }
            });
        }
    });
    
    <?php if (!Session::isLoggedIn()): ?>
    // Mobile menu toggle for non-logged users
    function toggleMobileMenu() {
        const navLinks = document.getElementById('navLinks');
        if (navLinks) {
            navLinks.classList.toggle('active');
        }
    }
    
    // Закрыть меню при клике на ссылку
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', function() {
            const navLinks = document.getElementById('navLinks');
            if (navLinks) {
                navLinks.classList.remove('active');
            }
        });
    });
    
    // Закрыть меню при клике вне его
    document.addEventListener('click', function(e) {
        const navLinks = document.getElementById('navLinks');
        const toggle = document.querySelector('.mobile-menu-toggle');
        
        if (navLinks && toggle && !navLinks.contains(e.target) && !toggle.contains(e.target)) {
            navLinks.classList.remove('active');
        }
    });
    <?php endif; ?>
    </script>
</body>
</html>
