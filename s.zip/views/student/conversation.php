<?php $title = __('messages.conversation_with'); include 'views/layouts/header.php'; ?>

<div class="container">
    <h1>💬 <?php echo __('messages.conversation_with'); ?> <?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?></h1>
    
    <div class="messages-container">
        <?php foreach ($messages as $message): ?>
        <div class="message <?php echo $message['sender_id'] == Session::getUserId() ? 'sent' : 'received'; ?>">
            <div class="message-header">
                <strong><?php echo $message['sender_name']; ?></strong>
                <span class="message-time"><?php echo date('M d, H:i', strtotime($message['created_at'])); ?></span>
            </div>
            <p><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
        </div>
        <?php endforeach; ?>
    </div>
    
    <form id="messageForm" class="message-form" action="/index.php?url=student/sendMessage">
        <input type="hidden" name="receiver_id" value="<?php echo $teacher['id']; ?>">
        <textarea name="message" placeholder="<?php echo __('messages.type_message'); ?>" required></textarea>
        <button type="submit" class="btn btn-primary">📤 <?php echo __('messages.send'); ?></button>
    </form>
</div>

<script>
document.getElementById('messageForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('<?php echo $this->action ?? "/index.php?url=student/sendMessage"; ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    });
});
</script>

<?php include 'views/layouts/footer.php'; ?>
