<?php $title = __('profile.title'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>👤 <?php echo __('profile.title'); ?></h1>
    </div>
    
    <form method="POST" enctype="multipart/form-data" class="form">
        <div class="form-group">
            <label>📸 <?php echo __('profile.avatar'); ?></label>
            <?php if ($user['avatar']): ?>
                <img src="/public/uploads/<?php echo $user['avatar']; ?>" alt="Avatar" class="profile-avatar">
            <?php endif; ?>
            <input type="file" name="avatar" accept="image/*">
        </div>
        
        <div class="form-group">
            <label>👤 <?php echo __('auth.first_name'); ?></label>
            <input type="text" name="first_name" value="<?php echo $user['first_name']; ?>" required>
        </div>
        
        <div class="form-group">
            <label>👤 <?php echo __('auth.last_name'); ?></label>
            <input type="text" name="last_name" value="<?php echo $user['last_name']; ?>" required>
        </div>
        
        <div class="form-group">
            <label>📧 <?php echo __('auth.email'); ?></label>
            <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
        </div>
        
        <div class="form-group">
            <label>🔑 <?php echo __('profile.new_password'); ?> <?php echo __('profile.leave_empty'); ?></label>
            <input type="password" name="new_password">
        </div>
        
        <button type="submit" class="btn btn-primary">💾 <?php echo __('profile.save'); ?></button>
    </form>
</div>

<?php include 'views/layouts/footer.php'; ?>
