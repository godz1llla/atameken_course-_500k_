<?php $title = __('certificates.title'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>🎓 <?php echo __('certificates.title'); ?></h1>
    </div>
    
    <?php if (count($certificates) > 0): ?>
        <div class="certificates-grid">
            <?php foreach ($certificates as $certificate): ?>
            <div class="certificate-card">
                <div style="font-size: 60px; margin-bottom: 20px;">🎓</div>
                <h3><?php echo $certificate['course_title']; ?></h3>
                <p><?php echo __('certificates.certificate_number'); ?>: <strong><?php echo $certificate['certificate_number']; ?></strong></p>
                <p><?php echo __('certificates.issued'); ?>: <?php echo date('F d, Y', strtotime($certificate['issued_at'])); ?></p>
                <a href="/index.php?url=student/certificate/<?php echo $certificate['certificate_number']; ?>" class="btn btn-primary">
                    👁️ <?php echo __('certificates.view'); ?>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="background: rgba(255, 255, 255, 0.98); padding: 60px; text-align: center; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
            <div style="font-size: 80px; margin-bottom: 20px;">🎓</div>
            <h3 style="color: #1f2937; margin-bottom: 15px;"><?php echo __('certificates.no_certificates'); ?></h3>
            <p style="color: #6b7280;"><?php echo __('certificates.complete_courses'); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>
