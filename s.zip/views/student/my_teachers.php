<?php $title = __('student.my_teachers'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>👨‍🏫 <?php echo __('student.my_teachers'); ?></h1>
    </div>
    
    <?php if (count($teachers) > 0): ?>
        <div class="courses-grid">
            <?php foreach ($teachers as $teacher): ?>
            <div class="course-card">
                <div style="width: 100%; height: 220px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; font-size: 80px;">👨‍🏫</div>
                <h3><?php echo $teacher['teacher_name']; ?></h3>
                <p><strong><?php echo __('nav.courses'); ?>:</strong> <?php echo $teacher['course_title']; ?></p>
                <p><small><?php echo $teacher['teacher_email']; ?></small></p>
                <a href="/index.php?url=student/conversation/<?php echo $teacher['teacher_id']; ?>" class="btn btn-primary">
                    💬 <?php echo __('student.send_message'); ?>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="background: rgba(255, 255, 255, 0.98); padding: 60px; text-align: center; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
            <div style="font-size: 80px; margin-bottom: 20px;">👨‍🏫</div>
            <h3 style="color: #1f2937; margin-bottom: 15px;"><?php echo __('student.no_teachers'); ?></h3>
            <p style="color: #6b7280;"><?php echo __('dashboard.no_courses'); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>

