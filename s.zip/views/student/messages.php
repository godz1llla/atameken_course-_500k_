<?php $title = __('messages.title'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>💬 <?php echo __('messages.title'); ?></h1>
    </div>
    
    <?php if (count($conversations) > 0): ?>
        <div class="conversations-list">
            <?php foreach ($conversations as $conversation): ?>
            <div class="conversation-item">
                <div class="conversation-avatar">
                    <?php if ($conversation['other_user_avatar']): ?>
                        <img src="/public/uploads/<?php echo $conversation['other_user_avatar']; ?>" alt="Avatar">
                    <?php else: ?>
                        <div class="avatar-placeholder"><?php echo substr($conversation['other_user_name'], 0, 1); ?></div>
                    <?php endif; ?>
                </div>
                <div class="conversation-info">
                    <h3><?php echo $conversation['other_user_name']; ?></h3>
                    <?php if ($conversation['course_title']): ?>
                        <p class="course-tag">📚 <?php echo $conversation['course_title']; ?></p>
                    <?php endif; ?>
                    <p class="last-message"><?php echo substr($conversation['last_message'], 0, 50); ?>...</p>
                    <p class="message-time"><?php echo date('M d, H:i', strtotime($conversation['last_message_time'])); ?></p>
                </div>
                <?php if ($conversation['unread_count'] > 0): ?>
                    <span class="unread-badge"><?php echo $conversation['unread_count']; ?></span>
                <?php endif; ?>
                <a href="/index.php?url=student/conversation/<?php echo $conversation['other_user_id']; ?>" class="btn btn-small">
                    <?php echo __('common.view'); ?>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="background: rgba(255, 255, 255, 0.98); padding: 60px; text-align: center; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
            <div style="font-size: 80px; margin-bottom: 20px;">💬</div>
            <p style="color: #6b7280;"><?php echo __('messages.no_messages'); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>
