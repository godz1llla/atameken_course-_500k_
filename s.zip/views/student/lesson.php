<?php $title = $lesson['title']; include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="lesson-header">
        <h1>📖 <?php echo $lesson['title']; ?></h1>
        <p class="breadcrumb">
            <a href="/index.php?url=student/course/<?php echo $course['id']; ?>">
                🏠 <?php echo $course['title']; ?>
            </a> / <?php echo $module['title']; ?>
        </p>
    </div>
    
    <div class="lesson-content">
        <?php if ($youtube_url): ?>
        <div class="video-container">
            <iframe 
                src="<?php echo $youtube_url; ?>" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen
                loading="lazy"
            ></iframe>
        </div>
        <?php endif; ?>
        
        <div class="lesson-text">
            <?php echo nl2br(htmlspecialchars($lesson['content'])); ?>
        </div>
        
        <?php if ($test): ?>
        <div class="lesson-test">
            <h3>📝 <?php echo $test['title']; ?></h3>
            <p><?php echo $test['description']; ?></p>
            <a href="/index.php?url=student/test/<?php echo $test['id']; ?>" class="btn btn-primary" style="margin-top: 15px;">
                📊 <?php echo __('lesson.take_test'); ?>
            </a>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="lesson-actions">
        <div>
            <?php if (!$is_completed): ?>
            <a href="/index.php?url=student/completeLesson/<?php echo $lesson['id']; ?>" class="btn btn-success">
                ✅ <?php echo __('lesson.mark_complete'); ?>
            </a>
            <?php else: ?>
            <span class="completed-badge">✓ <?php echo __('lesson.completed'); ?></span>
            <?php endif; ?>
        </div>
        
        <div class="lesson-navigation">
            <?php if ($prev_lesson): ?>
            <a href="/index.php?url=student/lesson/<?php echo $prev_lesson['id']; ?>" class="btn btn-secondary">
                ← <?php echo __('lesson.previous'); ?>
            </a>
            <?php endif; ?>
            
            <?php if ($next_lesson): ?>
            <a href="/index.php?url=student/lesson/<?php echo $next_lesson['id']; ?>" class="btn btn-secondary">
                <?php echo __('lesson.next'); ?> →
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>
