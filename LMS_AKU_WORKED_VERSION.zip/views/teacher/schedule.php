<?php $title = __('admin.class_schedule'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h1>📅 <?php echo __('admin.class_schedule'); ?></h1>
    </div>
    
    <div class="card">
        <div id="calendar"></div>
    </div>
</div>

<style>
#calendar {
    padding: 20px;
    min-height: 600px;
}

/* FullCalendar Customization */
.fc {
    font-family: inherit;
}

.fc-header-toolbar {
    margin-bottom: 20px;
}

.fc-button {
    background: var(--primary) !important;
    border: none !important;
    padding: 8px 16px !important;
    border-radius: var(--radius) !important;
    font-weight: 600 !important;
    transition: var(--transition) !important;
}

.fc-button:hover {
    background: var(--primary-dark) !important;
    transform: translateY(-2px) !important;
}

.fc-button-primary:not(:disabled).fc-button-active {
    background: var(--primary-dark) !important;
}

.fc-event {
    border: none !important;
    border-radius: 6px !important;
    padding: 4px 8px !important;
    cursor: pointer !important;
}

.fc-daygrid-event {
    border-radius: 6px !important;
}

.fc-day-today {
    background-color: rgba(115, 103, 240, 0.05) !important;
}

.fc-col-header-cell {
    background: var(--light-gray) !important;
    padding: 10px !important;
    font-weight: 600 !important;
}

.fc-daygrid-day {
    background: var(--white) !important;
}

@media (max-width: 768px) {
    #calendar {
        padding: 10px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        firstDay: 1,
        height: 'auto',
        events: function(fetchInfo, successCallback, failureCallback) {
            fetch('/index.php?url=teacher/getScheduleEvents')
                .then(response => response.json())
                .then(data => {
                    successCallback(data);
                })
                .catch(error => {
                    console.error('Error loading events:', error);
                    failureCallback(error);
                });
        },
        eventClick: function(info) {
            // При клике на событие (занятие) переходим на страницу с деталями
            window.location.href = '/index.php?url=teacher/classDetails/' + info.event.id;
        },
        dateClick: function(info) {
            // При клике на день можно показать занятия этого дня (опционально)
            console.log('Date clicked:', info.dateStr);
        }
    });
    
    calendar.render();
});
</script>

<?php include 'views/layouts/footer.php'; ?>

