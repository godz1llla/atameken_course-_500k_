<?php $title = __('teacher.grade_submission'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h1>📝 <?php echo __('teacher.grade_submission'); ?></h1>
        <a href="/index.php?url=teacher/viewSubmissions/<?php echo $homework['id']; ?>" class="btn btn-outline">← <?php echo __('common.back'); ?></a>
    </div>
    
    <div style="display: grid; gap: 30px;">
        <!-- Первая карточка: Ответ студента -->
        <div class="card">
            <h2>👤 <?php echo __('teacher.student_submission'); ?></h2>
            
            <div style="margin-top: 20px;">
                <p><strong><?php echo __('auth.first_name'); ?>:</strong> <?php echo htmlspecialchars($submission['student_name']); ?></p>
                <p><strong><?php echo __('auth.email'); ?>:</strong> <?php echo htmlspecialchars($submission['student_email']); ?></p>
                <p><strong><?php echo __('teacher.homework_title'); ?>:</strong> <?php echo htmlspecialchars($submission['homework_title']); ?></p>
                <p><strong><?php echo __('teacher.submitted_at'); ?>:</strong> <?php echo date('d.m.Y H:i', strtotime($submission['submitted_at'])); ?></p>
                <?php if ($submission['status'] === 'late'): ?>
                    <p style="color: var(--danger);"><strong>⚠️ <?php echo __('teacher.late_submission'); ?></strong></p>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($submission['submission_text'])): ?>
            <div style="margin-top: 20px; padding: 20px; background: var(--light-gray); border-radius: var(--radius);">
                <h3 style="margin-bottom: 15px;"><?php echo __('teacher.submission_text'); ?></h3>
                <div style="white-space: pre-wrap; line-height: 1.6;"><?php echo nl2br(htmlspecialchars($submission['submission_text'])); ?></div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($submission['file_path'])): ?>
            <div style="margin-top: 20px;">
                <h3 style="margin-bottom: 15px;"><?php echo __('teacher.attached_file'); ?></h3>
                <a href="/index.php?url=teacher/downloadFile/<?php echo $submission['id']; ?>" class="btn btn-info" target="_blank">
                    📎 <?php echo __('teacher.download_file'); ?>: <?php echo htmlspecialchars(basename($submission['file_path'])); ?>
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Вторая карточка: Оценка работы -->
        <div class="card">
            <h2>✅ <?php echo __('teacher.grade_work'); ?></h2>
            
            <form method="POST" action="/index.php?url=teacher/saveGrade" class="form" style="margin-top: 20px;">
                <input type="hidden" name="submission_id" value="<?php echo $submission['id']; ?>">
                
                <div class="form-group">
                    <label><?php echo __('teacher.grade'); ?> *</label>
                    <input type="number" name="grade" value="<?php echo $submission['grade'] ?? ''; ?>" required min="0" max="100" placeholder="0-100">
                    <small style="color: var(--gray); margin-top: 5px; display: block;"><?php echo __('teacher.grade_help'); ?></small>
                </div>
                
                <div class="form-group">
                    <label><?php echo __('teacher.comment'); ?></label>
                    <textarea name="comment" rows="5" placeholder="<?php echo __('teacher.comment_placeholder'); ?>"><?php echo htmlspecialchars($submission['teacher_comment'] ?? ''); ?></textarea>
                    <small style="color: var(--gray); margin-top: 5px; display: block;"><?php echo __('teacher.comment_help'); ?></small>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">💾 <?php echo __('teacher.save_grade'); ?></button>
                    <a href="/index.php?url=teacher/viewSubmissions/<?php echo $homework['id']; ?>" class="btn btn-outline">❌ <?php echo __('common.cancel'); ?></a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>

