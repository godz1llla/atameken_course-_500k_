<?php $title = __('admin.groups'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h1>👥 <?php echo __('admin.groups'); ?></h1>
        <?php 
        $baseUrl = (isset($is_manager) && $is_manager) ? 'manager' : 'admin';
        ?>
        <a href="/index.php?url=<?php echo $baseUrl; ?>/createGroup" class="btn btn-primary">➕ <?php echo __('admin.create_group'); ?></a>
    </div>
    
    <?php if (!empty($groups)): ?>
    <div class="card">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th><?php echo __('admin.group_name'); ?></th>
                    <th><?php echo __('course.title'); ?></th>
                    <th><?php echo __('course.teacher'); ?></th>
                    <th><?php echo __('admin.actions'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($groups as $group): ?>
                <tr>
                    <td data-label="ID"><?php echo htmlspecialchars($group['id']); ?></td>
                    <td data-label="<?php echo __('admin.group_name'); ?>">
                        <strong><?php echo htmlspecialchars($group['name']); ?></strong>
                    </td>
                    <td data-label="<?php echo __('course.title'); ?>">
                        <?php echo htmlspecialchars($group['course_title'] ?? 'N/A'); ?>
                    </td>
                    <td data-label="<?php echo __('course.teacher'); ?>">
                        <?php if (!empty($group['teacher_name'])): ?>
                            <?php echo htmlspecialchars($group['teacher_name']); ?>
                        <?php else: ?>
                            <span style="color: var(--gray);"><?php echo __('admin.no_teacher'); ?></span>
                        <?php endif; ?>
                    </td>
                    <td data-label="<?php echo __('admin.actions'); ?>" class="actions">
                        <?php 
                        $baseUrl = (isset($is_manager) && $is_manager) ? 'manager' : 'admin';
                        ?>
                        <a href="/index.php?url=<?php echo $baseUrl; ?>/groupDetails/<?php echo $group['id']; ?>" class="btn btn-small btn-info">👥 <?php echo __('admin.members'); ?></a>
                        <a href="/index.php?url=<?php echo $baseUrl; ?>/editGroup/<?php echo $group['id']; ?>" class="btn btn-small btn-primary">📝 <?php echo __('common.edit'); ?></a>
                        <a href="/index.php?url=<?php echo $baseUrl; ?>/deleteGroup/<?php echo $group['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('<?php echo __('common.confirm_delete'); ?>')">🗑️ <?php echo __('common.delete'); ?></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card">
        <div style="text-align: center; padding: 60px 20px;">
            <div style="font-size: 64px; margin-bottom: 20px;">👥</div>
            <h2 style="color: var(--gray); margin-bottom: 15px;"><?php echo __('admin.no_groups'); ?></h2>
            <p style="color: var(--gray); margin-bottom: 30px;"><?php echo __('admin.no_groups'); ?></p>
            <?php 
            $baseUrl = (isset($is_manager) && $is_manager) ? 'manager' : 'admin';
            ?>
            <a href="/index.php?url=<?php echo $baseUrl; ?>/createGroup" class="btn btn-primary">➕ <?php echo __('admin.create_group'); ?></a>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>

