<?php $title = isset($user) ? __('admin.edit_user') : __('admin.create_user'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h1><?php echo isset($user) ? '📝 ' . __('admin.edit_user') : '➕ ' . __('admin.create_user'); ?></h1>
        <?php 
        $baseUrl = (Session::getUserRole() === 'manager') ? 'manager' : 'admin';
        ?>
        <a href="/index.php?url=<?php echo $baseUrl; ?>/users" class="btn btn-outline">← <?php echo __('common.back'); ?></a>
    </div>
    
    <div class="card">
        <form method="POST" class="form">
            <div class="form-group">
                <label>👤 <?php echo __('auth.first_name'); ?></label>
                <input type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label>👤 <?php echo __('auth.last_name'); ?></label>
                <input type="text" name="last_name" value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label>📧 <?php echo __('auth.email'); ?></label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label>🔑 <?php echo __('auth.password'); ?> <?php echo isset($user) ? '(' . __('profile.leave_empty') . ')' : ''; ?></label>
                <input type="password" name="password" <?php echo !isset($user) ? 'required' : ''; ?>>
            </div>
            
            <div class="form-group">
                <label>🎭 <?php echo __('admin.role'); ?></label>
                <?php if (isset($is_manager) && $is_manager): ?>
                    <!-- Менеджер может создавать только студентов -->
                    <input type="hidden" name="role" value="student">
                    <input type="text" value="🎓 <?php echo __('dashboard.students'); ?>" disabled style="background: var(--light-gray); cursor: not-allowed;">
                    <small style="color: var(--gray); margin-top: 5px; display: block;"><?php echo __('manager.can_only_create_students'); ?></small>
                <?php else: ?>
                    <!-- Администратор может создавать любые роли -->
                    <select name="role" required id="roleSelect" onchange="toggleRateField()">
                        <option value="student" <?php echo (isset($user) && $user['role'] === 'student') ? 'selected' : ''; ?>>🎓 <?php echo __('dashboard.students'); ?></option>
                        <option value="teacher" <?php echo (isset($user) && $user['role'] === 'teacher') ? 'selected' : ''; ?>>👨‍🏫 <?php echo __('dashboard.teachers'); ?></option>
                        <option value="manager" <?php echo (isset($user) && $user['role'] === 'manager') ? 'selected' : ''; ?>>👨‍💼 <?php echo __('manager.manager'); ?></option>
                        <option value="admin" <?php echo (isset($user) && $user['role'] === 'admin') ? 'selected' : ''; ?>>👑 Admin</option>
                    </select>
                <?php endif; ?>
            </div>
            
            <?php if (!isset($is_manager) || !$is_manager): ?>
            <!-- Поле ставки только для учителей -->
            <div class="form-group" id="rateField" style="<?php echo (isset($user) && $user['role'] === 'teacher') || (!isset($user)) ? '' : 'display: none;'; ?>">
                <label>💰 <?php echo __('teacher.rate_per_class'); ?></label>
                <input type="number" name="rate_per_class" value="<?php echo isset($user['rate_per_class']) ? htmlspecialchars($user['rate_per_class']) : ''; ?>" min="0" step="0.01" placeholder="0.00">
                <small style="color: var(--gray); margin-top: 5px; display: block;"><?php echo __('teacher.rate_per_class_help'); ?></small>
            </div>
            <?php endif; ?>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-success">💾 <?php echo __('common.save'); ?></button>
                <a href="/index.php?url=<?php echo $baseUrl; ?>/users" class="btn btn-outline">❌ <?php echo __('common.cancel'); ?></a>
            </div>
        </form>
    </div>
</div>

<script>
function toggleRateField() {
    const roleSelect = document.getElementById('roleSelect');
    const rateField = document.getElementById('rateField');
    
    if (roleSelect && rateField) {
        if (roleSelect.value === 'teacher') {
            rateField.style.display = 'block';
        } else {
            rateField.style.display = 'none';
        }
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    toggleRateField();
});
</script>

<?php include 'views/layouts/footer.php'; ?>
