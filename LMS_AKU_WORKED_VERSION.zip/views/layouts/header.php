<!DOCTYPE html>
<html lang="<?php echo Language::getCurrentLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'LMS System'; ?></title>
    <link rel="stylesheet" href="/public/css/style.css">
</head>
<body>
    <?php if (Session::isLoggedIn()): ?>
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <a href="/index.php?url=<?php echo strtolower(Session::getUserRole()); ?>/dashboard" class="sidebar-logo">
                    LMS System
                </a>
            </div>
            
            <nav class="sidebar-nav">
                <ul class="sidebar-menu">
                    <?php if (Session::getUserRole() === 'admin'): ?>
                        <?php $currentUrl = $_GET['url'] ?? ''; ?>
                        <li class="menu-item">
                            <a href="/index.php?url=admin/dashboard" class="menu-link <?php echo strpos($currentUrl, 'admin/dashboard') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.dashboard'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=admin/users" class="menu-link <?php echo strpos($currentUrl, 'admin/users') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.users'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=admin/courses" class="menu-link <?php echo strpos($currentUrl, 'admin/courses') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.courses'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=admin/groups" class="menu-link <?php echo strpos($currentUrl, 'admin/groups') !== false || strpos($currentUrl, 'admin/createGroup') !== false || strpos($currentUrl, 'admin/editGroup') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('admin.groups'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=admin/schedule" class="menu-link <?php echo strpos($currentUrl, 'admin/schedule') !== false || strpos($currentUrl, 'admin/getScheduleEvents') !== false || strpos($currentUrl, 'admin/addScheduleEvent') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('admin.schedule'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=admin/achievements" class="menu-link <?php echo strpos($currentUrl, 'admin/achievements') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.achievements'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=admin/statistics" class="menu-link <?php echo strpos($currentUrl, 'admin/statistics') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.statistics'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=admin/enrollments" class="menu-link <?php echo strpos($currentUrl, 'admin/enrollments') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.enrollments'); ?></span>
                            </a>
                        </li>
                    <?php elseif (Session::getUserRole() === 'manager'): ?>
                        <?php $currentUrl = $_GET['url'] ?? ''; ?>
                        <li class="menu-item">
                            <a href="/index.php?url=manager/dashboard" class="menu-link <?php echo strpos($currentUrl, 'manager/dashboard') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.dashboard'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=manager/users" class="menu-link <?php echo strpos($currentUrl, 'manager/users') !== false || strpos($currentUrl, 'manager/createUser') !== false || strpos($currentUrl, 'manager/editUser') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('manager.students'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=manager/groups" class="menu-link <?php echo strpos($currentUrl, 'manager/groups') !== false || strpos($currentUrl, 'manager/createGroup') !== false || strpos($currentUrl, 'manager/editGroup') !== false || strpos($currentUrl, 'manager/groupDetails') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('admin.groups'); ?></span>
                            </a>
                        </li>
                    <?php elseif (Session::getUserRole() === 'teacher'): ?>
                        <?php $currentUrl = $_GET['url'] ?? ''; ?>
                        <li class="menu-item">
                            <a href="/index.php?url=teacher/dashboard" class="menu-link <?php echo strpos($currentUrl, 'teacher/dashboard') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.dashboard'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=teacher/schedule" class="menu-link <?php echo strpos($currentUrl, 'teacher/schedule') !== false || strpos($currentUrl, 'teacher/classDetails') !== false || strpos($currentUrl, 'teacher/getScheduleEvents') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('admin.schedule'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=teacher/messages" class="menu-link <?php echo strpos($currentUrl, 'teacher/messages') !== false || strpos($currentUrl, 'teacher/conversation') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.messages'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=teacher/reports" class="menu-link <?php echo strpos($currentUrl, 'teacher/reports') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('teacher.reports'); ?></span>
                            </a>
                        </li>
                    <?php elseif (Session::getUserRole() === 'student'): ?>
                        <?php $currentUrl = $_GET['url'] ?? ''; ?>
                        <li class="menu-item">
                            <a href="/index.php?url=student/dashboard" class="menu-link <?php echo strpos($currentUrl, 'student/dashboard') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.dashboard'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=student/schedule" class="menu-link <?php echo strpos($currentUrl, 'student/schedule') !== false || strpos($currentUrl, 'student/getMyScheduleEvents') !== false || strpos($currentUrl, 'student/getAttendanceStatus') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('student.my_schedule'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=student/statistics" class="menu-link <?php echo strpos($currentUrl, 'student/statistics') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.statistics'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=student/achievements" class="menu-link <?php echo strpos($currentUrl, 'student/achievements') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.achievements'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=student/certificates" class="menu-link <?php echo strpos($currentUrl, 'student/certificates') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.certificates'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=student/myTeachers" class="menu-link <?php echo strpos($currentUrl, 'student/myTeachers') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('student.my_teachers'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=student/messages" class="menu-link <?php echo strpos($currentUrl, 'student/messages') !== false || strpos($currentUrl, 'student/conversation') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.messages'); ?></span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/index.php?url=student/profile" class="menu-link <?php echo strpos($currentUrl, 'student/profile') !== false ? 'active' : ''; ?>">
                                <span class="menu-text"><?php echo __('nav.profile'); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            
            <div class="sidebar-footer">
                <div class="lang-switcher-sidebar">
                    <select class="lang-select-sidebar" onchange="window.location.href='?lang='+this.value+'&url='+new URLSearchParams(window.location.search).get('url')">
                        <?php foreach (Language::getLanguages() as $code => $name): ?>
                            <option value="<?php echo $code; ?>" <?php echo Language::getCurrentLanguage() === $code ? 'selected' : ''; ?>>
                                <?php echo $name; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <a href="/index.php?url=auth/logout" class="sidebar-logout">
                    <span class="menu-text"><?php echo __('nav.logout'); ?></span>
                </a>
            </div>
        </aside>
        
        <!-- Main Content Area -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" onclick="toggleSidebar()">☰</button>
                    <div class="search-box">
                        <input type="text" placeholder="<?php echo __('common.search'); ?>" class="search-input">
                    </div>
                </div>
                <div class="top-bar-right">
                    <div class="top-bar-user">
                        <span class="user-name-small"><?php echo Session::get('user_name'); ?></span>
                    </div>
                </div>
            </header>
            
            <!-- Content Area -->
            <div class="content-area">

    <?php else: ?>
    <!-- For non-logged in users, keep old structure -->
    <div class="main-container">
    <?php endif; ?>
