<?php

define('BASE_URL', 'http://localhost');
define('SITE_NAME', 'LMS System');

define('UPLOAD_DIR', __DIR__ . '/../public/uploads/');
define('MAX_FILE_SIZE', 10485760);

define('DB_HOST', 'localhost');
define('DB_NAME', 'infogok1_AKUUUU');
define('DB_USER', 'infogok1_AKUUUU');
define('DB_PASS', 'Gabi2005@');

date_default_timezone_set('UTC');

