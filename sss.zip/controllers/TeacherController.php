<?php

class TeacherController extends Controller {
    
    public function __construct() {
        Session::requireRole('teacher');
    }
    
    public function dashboard() {
        $courseModel = $this->model('Course');
        $messageModel = $this->model('Message');
        
        $userId = Session::getUserId();
        $courses = $courseModel->getByTeacher($userId);
        $unreadMessages = $messageModel->getUnreadCount($userId);
        
        $this->view('teacher/dashboard', [
            'courses' => $courses,
            'unread_messages' => $unreadMessages
        ]);
    }
    
    public function messages() {
        $messageModel = $this->model('Message');
        $userId = Session::getUserId();
        
        $conversations = $messageModel->getConversationsList($userId);
        
        $this->view('teacher/messages', ['conversations' => $conversations]);
    }
    
    public function conversation($studentId) {
        $messageModel = $this->model('Message');
        $userModel = $this->model('User');
        
        $userId = Session::getUserId();
        $student = $userModel->findById($studentId);
        $messages = $messageModel->getConversation($userId, $studentId);
        
        $messageModel->markAsRead($userId, $studentId);
        
        $this->view('teacher/conversation', [
            'student' => $student,
            'messages' => $messages
        ]);
    }
    
    public function sendMessage() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $messageModel = $this->model('Message');
            
            $userId = Session::getUserId();
            $receiverId = $_POST['receiver_id'];
            $courseId = $_POST['course_id'] ?? null;
            $subject = $_POST['subject'] ?? '';
            $message = $_POST['message'];
            
            $messageModel->sendMessage($userId, $receiverId, $courseId, $subject, $message);
            
            $this->json(['success' => true]);
        }
    }
    
    public function courseStudents($courseId) {
        $courseModel = $this->model('Course');
        $userCourseModel = $this->model('UserCourse');
        
        $course = $courseModel->findById($courseId);
        
        $stmt = $userCourseModel->db->prepare("
            SELECT u.*, uc.enrolled_at, uc.completed_at 
            FROM users u
            INNER JOIN user_courses uc ON u.id = uc.user_id
            WHERE uc.course_id = ?
        ");
        $stmt->execute([$courseId]);
        $students = $stmt->fetchAll();
        
        foreach ($students as &$student) {
            $student['progress'] = $userCourseModel->getCourseProgress($student['id'], $courseId);
        }
        
        $this->view('teacher/course_students', [
            'course' => $course,
            'students' => $students
        ]);
    }
}

