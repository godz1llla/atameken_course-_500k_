<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'LMS System'; ?></title>
    <link rel="stylesheet" href="/public/css/style.css">
</head>
<body>
    <?php if (Session::isLoggedIn()): ?>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/index.php?url=<?php echo strtolower(Session::getUserRole()); ?>/dashboard" class="logo">
                🎓 LMS System
            </a>
            <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">☰</button>
            <div class="nav-links" id="navLinks">
                <?php if (Session::getUserRole() === 'admin'): ?>
                    <a href="/index.php?url=admin/dashboard">🏠 <span><?php echo __('nav.dashboard'); ?></span></a>
                    <a href="/index.php?url=admin/users">👥 <span><?php echo __('nav.users'); ?></span></a>
                    <a href="/index.php?url=admin/courses">📚 <span><?php echo __('nav.courses'); ?></span></a>
                    <a href="/index.php?url=admin/achievements">🏆 <span><?php echo __('nav.achievements'); ?></span></a>
                    <a href="/index.php?url=admin/statistics">📊 <span><?php echo __('nav.statistics'); ?></span></a>
                    <a href="/index.php?url=admin/enrollments">📝 <span><?php echo __('nav.enrollments'); ?></span></a>
                <?php elseif (Session::getUserRole() === 'teacher'): ?>
                    <a href="/index.php?url=teacher/dashboard">🏠 <span><?php echo __('nav.dashboard'); ?></span></a>
                    <a href="/index.php?url=teacher/messages">💬 <span><?php echo __('nav.messages'); ?></span></a>
                <?php elseif (Session::getUserRole() === 'student'): ?>
                    <a href="/index.php?url=student/dashboard">🏠 <span><?php echo __('nav.dashboard'); ?></span></a>
                    <a href="/index.php?url=student/statistics">📊 <span><?php echo __('nav.statistics'); ?></span></a>
                    <a href="/index.php?url=student/achievements">🏆 <span><?php echo __('nav.achievements'); ?></span></a>
                    <a href="/index.php?url=student/certificates">🎓 <span><?php echo __('nav.certificates'); ?></span></a>
                    <a href="/index.php?url=student/myTeachers">👨‍🏫 <span><?php echo __('student.my_teachers'); ?></span></a>
                    <a href="/index.php?url=student/messages">💬 <span><?php echo __('nav.messages'); ?></span></a>
                    <a href="/index.php?url=student/profile">👤 <span><?php echo __('nav.profile'); ?></span></a>
                <?php endif; ?>
                
                <div class="nav-divider"></div>
                
                <div class="lang-switcher">
                    <select onchange="window.location.href='?lang='+this.value+'&url='+new URLSearchParams(window.location.search).get('url')">
                        <?php foreach (Language::getLanguages() as $code => $name): ?>
                            <option value="<?php echo $code; ?>" <?php echo Language::getCurrentLanguage() === $code ? 'selected' : ''; ?>>
                                <?php echo $name; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <a href="/index.php?url=auth/logout" class="logout-btn">🚪 <span><?php echo __('nav.logout'); ?></span></a>
                
                <div class="user-profile">
                    <div class="user-avatar">👤</div>
                    <span class="user-name"><?php echo Session::get('user_name'); ?></span>
                </div>
            </div>
        </div>
    </nav>
    <?php endif; ?>
    
    <div class="main-container">

