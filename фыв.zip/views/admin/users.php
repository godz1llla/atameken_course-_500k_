<?php $title = __('nav.users'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>👥 <?php echo __('nav.users'); ?></h1>
        <a href="/index.php?url=admin/createUser" class="btn btn-primary">➕ <?php echo __('admin.create_user'); ?></a>
    </div>
    
    <table class="data-table">
        <thead>
            <tr>
                <th>ID</th>
                <th><?php echo __('auth.first_name'); ?></th>
                <th><?php echo __('auth.email'); ?></th>
                <th><?php echo __('admin.role'); ?></th>
                <th><?php echo __('admin.status'); ?></th>
                <th><?php echo __('admin.actions'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td data-label="ID"><?php echo $user['id']; ?></td>
                <td data-label="<?php echo __('auth.first_name'); ?>"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></td>
                <td data-label="<?php echo __('auth.email'); ?>"><?php echo $user['email']; ?></td>
                <td data-label="<?php echo __('admin.role'); ?>"><span class="badge"><?php echo $user['role']; ?></span></td>
                <td data-label="<?php echo __('admin.status'); ?>">
                    <span class="status <?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                        <?php echo $user['is_active'] ? __('admin.active') : __('admin.inactive'); ?>
                    </span>
                </td>
                <td data-label="<?php echo __('admin.actions'); ?>" class="actions">
                    <a href="/index.php?url=admin/editUser/<?php echo $user['id']; ?>" class="btn btn-small">📝 <?php echo __('common.edit'); ?></a>
                    <a href="/index.php?url=admin/toggleUserStatus/<?php echo $user['id']; ?>" class="btn btn-small btn-warning">🔄</a>
                    <a href="/index.php?url=admin/deleteUser/<?php echo $user['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('<?php echo __('common.confirm_delete'); ?>')">🗑️ <?php echo __('common.delete'); ?></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'views/layouts/footer.php'; ?>
