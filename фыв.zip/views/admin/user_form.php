<?php $title = isset($user) ? __('admin.edit_user') : __('admin.create_user'); include 'views/layouts/header.php'; ?>

<div class="container">
    <h1><?php echo isset($user) ? '📝 ' . __('admin.edit_user') : '➕ ' . __('admin.create_user'); ?></h1>
    
    <form method="POST" class="form">
        <div class="form-group">
            <label>👤 <?php echo __('auth.first_name'); ?></label>
            <input type="text" name="first_name" value="<?php echo $user['first_name'] ?? ''; ?>" required>
        </div>
        
        <div class="form-group">
            <label>👤 <?php echo __('auth.last_name'); ?></label>
            <input type="text" name="last_name" value="<?php echo $user['last_name'] ?? ''; ?>" required>
        </div>
        
        <div class="form-group">
            <label>📧 <?php echo __('auth.email'); ?></label>
            <input type="email" name="email" value="<?php echo $user['email'] ?? ''; ?>" required>
        </div>
        
        <div class="form-group">
            <label>🔑 <?php echo __('auth.password'); ?> <?php echo isset($user) ? '(' . __('profile.leave_empty') . ')' : ''; ?></label>
            <input type="password" name="password" <?php echo !isset($user) ? 'required' : ''; ?>>
        </div>
        
        <div class="form-group">
            <label>🎭 <?php echo __('admin.role'); ?></label>
            <select name="role" required>
                <option value="student" <?php echo (isset($user) && $user['role'] === 'student') ? 'selected' : ''; ?>>🎓 <?php echo __('dashboard.students'); ?></option>
                <option value="teacher" <?php echo (isset($user) && $user['role'] === 'teacher') ? 'selected' : ''; ?>>👨‍🏫 <?php echo __('dashboard.teachers'); ?></option>
                <option value="admin" <?php echo (isset($user) && $user['role'] === 'admin') ? 'selected' : ''; ?>>👑 Admin</option>
            </select>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">💾 <?php echo __('common.save'); ?></button>
            <a href="/index.php?url=admin/users" class="btn btn-secondary">❌ <?php echo __('common.cancel'); ?></a>
        </div>
    </form>
</div>

<?php include 'views/layouts/footer.php'; ?>
