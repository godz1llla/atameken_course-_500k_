<?php $title = $test['title']; include 'views/layouts/header.php'; ?>

<div class="container">
    <h1>📝 <?php echo $test['title']; ?></h1>
    <p><?php echo $test['description']; ?></p>
    
    <?php if ($test['time_limit']): ?>
    <p class="test-info">⏱ <?php echo __('test.time_limit'); ?>: <?php echo $test['time_limit']; ?> <?php echo __('time.minutes'); ?></p>
    <?php endif; ?>
    
    <?php if ($test['max_attempts']): ?>
    <p class="test-info">🔄 <?php echo __('test.max_attempts'); ?>: <?php echo $test['max_attempts']; ?></p>
    <p class="test-info">📊 <?php echo __('test.your_attempts'); ?>: <?php echo count($results); ?></p>
    <?php endif; ?>
    
    <?php if ($test['max_attempts'] && count($results) >= $test['max_attempts']): ?>
        <div class="alert alert-warning">⚠️ You have reached the maximum number of attempts.</div>
        <a href="/index.php?url=student/testResult/<?php echo $test['id']; ?>" class="btn btn-primary"><?php echo __('common.view'); ?> <?php echo __('test.result'); ?></a>
    <?php else: ?>
        <form method="POST" action="/index.php?url=student/submitTest/<?php echo $test['id']; ?>" class="test-form" data-time-limit="<?php echo $test['time_limit']; ?>">
            <?php foreach ($questions as $index => $question): ?>
            <div class="question-block">
                <h3><?php echo __('test.question'); ?> <?php echo $index + 1; ?></h3>
                <p><?php echo $question['question']; ?></p>
                
                <div class="answers">
                    <?php foreach ($question['answers'] as $answer): ?>
                    <label class="answer-option">
                        <input type="radio" name="question_<?php echo $question['id']; ?>" value="<?php echo $answer['id']; ?>" required>
                        <span><?php echo $answer['answer_text']; ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
            
            <button type="submit" class="btn btn-primary">✅ <?php echo __('test.submit'); ?></button>
        </form>
    <?php endif; ?>
    
    <?php if (count($results) > 0): ?>
    <div class="previous-attempts" style="margin-top: 40px;">
        <h3>📜 Previous Attempts</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo __('test.score'); ?></th>
                    <th><?php echo __('admin.status'); ?></th>
                    <th><?php echo __('certificates.issued'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $result): ?>
                <tr>
                    <td><?php echo $result['attempt_number']; ?></td>
                    <td><?php echo $result['score']; ?>%</td>
                    <td>
                        <span class="status <?php echo $result['passed'] ? 'active' : 'inactive'; ?>">
                            <?php echo $result['passed'] ? __('test.passed') : __('test.failed'); ?>
                        </span>
                    </td>
                    <td><?php echo date('Y-m-d H:i', strtotime($result['completed_at'])); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>
