<?php

class AdminController extends Controller {
    
    public function __construct() {
        Session::requireRole('admin');
    }
    
    public function dashboard() {
        $userModel = $this->model('User');
        $courseModel = $this->model('Course');
        
        $stats = [
            'total_users' => count($userModel->findAll()),
            'total_students' => count($userModel->getAllByRole('student')),
            'total_teachers' => count($userModel->getAllByRole('teacher')),
            'total_courses' => count($courseModel->findAll())
        ];
        
        $this->view('admin/dashboard', ['stats' => $stats]);
    }
    
    public function statistics() {
        $statisticsModel = $this->model('Statistics');
        
        $studentsStats = $statisticsModel->getAllStudentsStats();
        
        $this->view('admin/statistics', ['students' => $studentsStats]);
    }
    
    public function users() {
        $userModel = $this->model('User');
        $users = $userModel->findAll();
        
        $this->view('admin/users', ['users' => $users]);
    }
    
    public function createUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userModel = $this->model('User');
            
            $data = [
                'email' => $_POST['email'],
                'password' => $_POST['password'],
                'first_name' => $_POST['first_name'],
                'last_name' => $_POST['last_name'],
                'role' => $_POST['role']
            ];
            
            $userModel->createUser($data);
            $this->redirect('admin/users');
        } else {
            $this->view('admin/user_form');
        }
    }
    
    public function editUser($id) {
        $userModel = $this->model('User');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'email' => $_POST['email'],
                'first_name' => $_POST['first_name'],
                'last_name' => $_POST['last_name'],
                'role' => $_POST['role']
            ];
            
            if (!empty($_POST['password'])) {
                $userModel->updatePassword($id, $_POST['password']);
            }
            
            $userModel->update($id, $data);
            $this->redirect('admin/users');
        } else {
            $user = $userModel->findById($id);
            $this->view('admin/user_form', ['user' => $user]);
        }
    }
    
    public function deleteUser($id) {
        $userModel = $this->model('User');
        $userModel->delete($id);
        $this->redirect('admin/users');
    }
    
    public function toggleUserStatus($id) {
        $userModel = $this->model('User');
        $userModel->toggleActive($id);
        $this->redirect('admin/users');
    }
    
    public function courses() {
        $courseModel = $this->model('Course');
        $courses = $courseModel->getWithTeacher();
        
        $this->view('admin/courses', ['courses' => $courses]);
    }
    
    public function createCourse() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $courseModel = $this->model('Course');
            
            $imagePath = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
                $imagePath = $this->uploadFile($_FILES['image'], 'course_images');
            }
            
            $data = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'teacher_id' => $_POST['teacher_id'],
                'image' => $imagePath,
                'is_published' => isset($_POST['is_published']) ? 1 : 0
            ];
            
            $courseModel->create($data);
            $this->redirect('admin/courses');
        } else {
            $userModel = $this->model('User');
            $teachers = $userModel->getAllByRole('teacher');
            
            $this->view('admin/course_form', ['teachers' => $teachers]);
        }
    }
    
    public function editCourse($id) {
        $courseModel = $this->model('Course');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'teacher_id' => $_POST['teacher_id'],
                'is_published' => isset($_POST['is_published']) ? 1 : 0
            ];
            
            if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
                $data['image'] = $this->uploadFile($_FILES['image'], 'course_images');
            }
            
            $courseModel->update($id, $data);
            $this->redirect('admin/courses');
        } else {
            $userModel = $this->model('User');
            $teachers = $userModel->getAllByRole('teacher');
            $course = $courseModel->findById($id);
            
            $this->view('admin/course_form', ['course' => $course, 'teachers' => $teachers]);
        }
    }
    
    public function deleteCourse($id) {
        $courseModel = $this->model('Course');
        $courseModel->delete($id);
        $this->redirect('admin/courses');
    }
    
    public function manageCourse($id) {
        $courseModel = $this->model('Course');
        $moduleModel = $this->model('Module');
        $weeklyTestModel = $this->model('WeeklyTest');
        
        $course = $courseModel->findById($id);
        $modules = $moduleModel->getByCourse($id);
        $weeklyTests = $weeklyTestModel->getByCourse($id);
        
        foreach ($modules as &$module) {
            $module['lessons'] = $courseModel->getLessons($module['id']);
        }
        
        $this->view('admin/manage_course', [
            'course' => $course, 
            'modules' => $modules,
            'weekly_tests' => $weeklyTests
        ]);
    }
    
    public function createModule($courseId) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $moduleModel = $this->model('Module');
            
            $data = [
                'course_id' => $courseId,
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'order_num' => $_POST['order_num'] ?? 0
            ];
            
            $moduleModel->create($data);
            $this->redirect('admin/manageCourse/' . $courseId);
        }
    }
    
    public function deleteModule($id) {
        $moduleModel = $this->model('Module');
        $module = $moduleModel->findById($id);
        $courseId = $module['course_id'];
        
        $moduleModel->delete($id);
        $this->redirect('admin/manageCourse/' . $courseId);
    }
    
    public function createLesson($moduleId) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $lessonModel = $this->model('Lesson');
            $moduleModel = $this->model('Module');
            
            $data = [
                'module_id' => $moduleId,
                'title' => $_POST['title'],
                'content' => $_POST['content'],
                'video_url' => $_POST['video_url'] ?? null,
                'order_num' => $_POST['order_num'] ?? 0
            ];
            
            $lessonModel->create($data);
            
            $module = $moduleModel->findById($moduleId);
            $this->redirect('admin/manageCourse/' . $module['course_id']);
        }
    }
    
    public function editLesson($id) {
        $lessonModel = $this->model('Lesson');
        $moduleModel = $this->model('Module');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'title' => $_POST['title'],
                'content' => $_POST['content'],
                'video_url' => $_POST['video_url'] ?? null,
                'order_num' => $_POST['order_num'] ?? 0
            ];
            
            $lessonModel->update($id, $data);
            
            $lesson = $lessonModel->findById($id);
            $module = $moduleModel->findById($lesson['module_id']);
            $this->redirect('admin/manageCourse/' . $module['course_id']);
        }
    }
    
    public function deleteLesson($id) {
        $lessonModel = $this->model('Lesson');
        $moduleModel = $this->model('Module');
        
        $lesson = $lessonModel->findById($id);
        $module = $moduleModel->findById($lesson['module_id']);
        
        $lessonModel->delete($id);
        $this->redirect('admin/manageCourse/' . $module['course_id']);
    }
    
    public function achievements() {
        $achievementModel = $this->model('Achievement');
        $achievements = $achievementModel->findAll();
        
        $this->view('admin/achievements', ['achievements' => $achievements]);
    }
    
    public function createAchievement() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $achievementModel = $this->model('Achievement');
            
            $iconPath = null;
            if (isset($_FILES['icon']) && $_FILES['icon']['error'] === 0) {
                $iconPath = $this->uploadFile($_FILES['icon'], 'achievement_icons');
            }
            
            $data = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'icon' => $iconPath,
                'condition_type' => $_POST['condition_type'],
                'condition_value' => $_POST['condition_value']
            ];
            
            $achievementModel->create($data);
            $this->redirect('admin/achievements');
        } else {
            $this->view('admin/achievement_form');
        }
    }
    
    public function deleteAchievement($id) {
        $achievementModel = $this->model('Achievement');
        $achievementModel->delete($id);
        $this->redirect('admin/achievements');
    }
    
    public function enrollments() {
        $userModel = $this->model('User');
        $courseModel = $this->model('Course');
        
        $students = $userModel->getAllByRole('student');
        $courses = $courseModel->findAll();
        
        $this->view('admin/enrollments', ['students' => $students, 'courses' => $courses]);
    }
    
    public function enrollStudent() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userCourseModel = $this->model('UserCourse');
            
            $userId = $_POST['user_id'];
            $courseId = $_POST['course_id'];
            
            $userCourseModel->enroll($userId, $courseId);
        }
        
        $this->redirect('admin/enrollments');
    }
    
    private function uploadFile($file, $folder) {
        $uploadDir = UPLOAD_DIR . $folder . '/';
        
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $filepath = $uploadDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            return $folder . '/' . $filename;
        }
        
        return null;
    }
}

