<?php $title = __('teacher.reports'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h1>📊 <?php echo __('teacher.reports'); ?></h1>
    </div>
    
    <!-- Фильтр по дате -->
    <div class="card" style="margin-bottom: 30px;">
        <h2>📅 <?php echo __('teacher.filter_period'); ?></h2>
        <form method="POST" class="form" style="margin-top: 20px;">
            <div style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 15px; align-items: end;">
                <div class="form-group">
                    <label><?php echo __('teacher.start_date'); ?> *</label>
                    <input type="date" name="start_date" value="<?php echo date('Y-m-d', strtotime($startDate)); ?>" required>
                </div>
                <div class="form-group">
                    <label><?php echo __('teacher.end_date'); ?> *</label>
                    <input type="date" name="end_date" value="<?php echo date('Y-m-d', strtotime($endDate)); ?>" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">📊 <?php echo __('teacher.generate_report'); ?></button>
                </div>
            </div>
        </form>
    </div>
    
    <!-- Карточка "Сводка за период" -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <h3>📚 <?php echo __('teacher.classes_conducted'); ?></h3>
            <p class="stat-number"><?php echo $reportData['total_classes']; ?></p>
            <small style="color: var(--gray);"><?php echo __('teacher.classes_conducted_description'); ?></small>
        </div>
        
        <div class="stat-card">
            <h3>⏱️ <?php echo __('teacher.total_hours'); ?></h3>
            <p class="stat-number"><?php echo $reportData['total_hours']; ?></p>
            <small style="color: var(--gray);"><?php echo __('teacher.total_hours_description'); ?></small>
        </div>
        
        <div class="stat-card">
            <h3>✅ <?php echo __('teacher.average_attendance'); ?></h3>
            <p class="stat-number"><?php echo $reportData['average_attendance_percent']; ?>%</p>
            <small style="color: var(--gray);"><?php echo __('teacher.average_attendance_description'); ?></small>
        </div>
    </div>
    
    <!-- Карточка "Расчет зарплаты" -->
    <div class="card" style="margin-bottom: 30px;">
        <h2>💰 <?php echo __('teacher.salary_calculation'); ?></h2>
        
        <?php if ($ratePerClass > 0): ?>
        <div style="margin-top: 20px; padding: 20px; background: var(--light-gray); border-radius: var(--radius);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <span style="font-size: 16px; color: var(--gray);"><?php echo __('teacher.classes_conducted'); ?>:</span>
                <strong style="font-size: 18px;"><?php echo $reportData['total_classes']; ?></strong>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <span style="font-size: 16px; color: var(--gray);"><?php echo __('teacher.rate_per_class'); ?>:</span>
                <strong style="font-size: 18px;"><?php echo number_format($ratePerClass, 2, '.', ' '); ?> ₸</strong>
            </div>
            <div style="border-top: 2px solid var(--primary); padding-top: 15px; margin-top: 15px; display: flex; justify-content: space-between; align-items: center;">
                <span style="font-size: 20px; font-weight: 700; color: var(--dark);"><?php echo __('teacher.total_salary'); ?>:</span>
                <strong style="font-size: 28px; font-weight: 700; color: var(--primary);"><?php echo number_format($salary, 2, '.', ' '); ?> ₸</strong>
            </div>
        </div>
        <?php else: ?>
        <div style="margin-top: 20px; padding: 20px; background: #fef3c7; border-radius: var(--radius); border: 1px solid var(--warning);">
            <p style="color: var(--warning); margin: 0;">
                ⚠️ <?php echo __('teacher.rate_not_set'); ?>
            </p>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Карточка "Детализация занятий" -->
    <div class="card">
        <h2>📋 <?php echo __('teacher.classes_detail'); ?></h2>
        
        <?php if (!empty($reportData['detailed_data'])): ?>
        <div style="margin-top: 20px;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th><?php echo __('teacher.class_date'); ?></th>
                        <th><?php echo __('admin.group_name'); ?></th>
                        <th><?php echo __('lesson.title'); ?></th>
                        <th><?php echo __('teacher.students_count'); ?></th>
                        <th><?php echo __('teacher.attendance_percent'); ?></th>
                        <th><?php echo __('teacher.duration'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reportData['detailed_data'] as $detail): ?>
                    <tr>
                        <td data-label="<?php echo __('teacher.class_date'); ?>">
                            <strong><?php echo date('d.m.Y', strtotime($detail['date'])); ?></strong><br>
                            <small style="color: var(--gray);"><?php echo date('H:i', strtotime($detail['date'])); ?></small>
                        </td>
                        <td data-label="<?php echo __('admin.group_name'); ?>">
                            <?php echo htmlspecialchars($detail['group_name']); ?>
                        </td>
                        <td data-label="<?php echo __('lesson.title'); ?>">
                            <?php echo htmlspecialchars($detail['title']); ?><br>
                            <small style="color: var(--gray);"><?php echo htmlspecialchars($detail['course_title']); ?></small>
                        </td>
                        <td data-label="<?php echo __('teacher.students_count'); ?>">
                            <strong style="color: var(--primary);"><?php echo $detail['student_count']; ?></strong>
                            <?php if ($detail['present_count'] > 0): ?>
                                <small style="color: var(--success); display: block;"><?php echo __('teacher.present'); ?>: <?php echo $detail['present_count']; ?></small>
                            <?php endif; ?>
                        </td>
                        <td data-label="<?php echo __('teacher.attendance_percent'); ?>">
                            <div style="display: inline-flex; align-items: center; gap: 8px;">
                                <div class="progress-bar" style="width: 60px; height: 8px; display: inline-block;">
                                    <div class="progress-fill" style="width: <?php echo $detail['attendance_percent']; ?>%"></div>
                                </div>
                                <strong style="color: <?php echo $detail['attendance_percent'] >= 70 ? 'var(--success)' : 'var(--danger)'; ?>">
                                    <?php echo $detail['attendance_percent']; ?>%
                                </strong>
                            </div>
                        </td>
                        <td data-label="<?php echo __('teacher.duration'); ?>">
                            <?php echo $detail['duration_hours']; ?> <?php echo __('teacher.hours'); ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div style="text-align: center; padding: 60px 20px; margin-top: 20px;">
            <div style="font-size: 64px; margin-bottom: 20px;">📊</div>
            <h2 style="color: var(--gray); margin-bottom: 15px;"><?php echo __('teacher.no_classes_in_period'); ?></h2>
            <p style="color: var(--gray);"><?php echo __('teacher.no_classes_in_period_description'); ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>

