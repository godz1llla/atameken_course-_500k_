<?php $title = __('teacher.homework_submissions'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <div>
            <h1>📝 <?php echo __('teacher.homework_submissions'); ?></h1>
            <p style="color: var(--gray); margin-top: 10px;">
                <strong><?php echo __('teacher.homework_title'); ?>:</strong> <?php echo htmlspecialchars($homework['title']); ?><br>
                <strong><?php echo __('lesson.title'); ?>:</strong> <?php echo htmlspecialchars($homework['lesson_title']); ?><br>
                <strong><?php echo __('teacher.due_date'); ?>:</strong> <?php echo date('d.m.Y H:i', strtotime($homework['due_date'])); ?>
            </p>
        </div>
        <a href="/index.php?url=admin/manageCourse/<?php echo $homework['course_id']; ?>" class="btn btn-outline">← <?php echo __('common.back'); ?></a>
    </div>
    
    <?php if (!empty($submissions)): ?>
    <div class="card">
        <table class="data-table">
            <thead>
                <tr>
                    <th><?php echo __('auth.first_name'); ?></th>
                    <th><?php echo __('auth.email'); ?></th>
                    <th><?php echo __('teacher.submitted_at'); ?></th>
                    <th><?php echo __('teacher.status'); ?></th>
                    <th><?php echo __('teacher.grade'); ?></th>
                    <th><?php echo __('admin.actions'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($submissions as $submission): ?>
                <tr>
                    <td data-label="<?php echo __('auth.first_name'); ?>">
                        <strong><?php echo htmlspecialchars($submission['student_name']); ?></strong>
                    </td>
                    <td data-label="<?php echo __('auth.email'); ?>">
                        <?php echo htmlspecialchars($submission['student_email']); ?>
                    </td>
                    <td data-label="<?php echo __('teacher.submitted_at'); ?>">
                        <?php echo date('d.m.Y H:i', strtotime($submission['submitted_at'])); ?>
                        <?php if ($submission['status'] === 'late'): ?>
                            <span style="color: var(--danger); font-size: 12px; margin-left: 5px;">⚠️ <?php echo __('teacher.late_submission'); ?></span>
                        <?php endif; ?>
                    </td>
                    <td data-label="<?php echo __('teacher.status'); ?>">
                        <?php
                        $statusBadges = [
                            'submitted' => ['badge-default', '📤 ' . __('teacher.status_submitted')],
                            'late' => ['badge-warning', '⏰ ' . __('teacher.status_late')],
                            'graded' => ['badge-success', '✅ ' . __('teacher.status_graded')],
                            'resubmit' => ['badge-danger', '🔄 ' . __('teacher.status_resubmit')]
                        ];
                        $status = $submission['status'];
                        $badgeClass = $statusBadges[$status][0] ?? 'badge-default';
                        $badgeText = $statusBadges[$status][1] ?? $status;
                        ?>
                        <span class="badge <?php echo $badgeClass; ?>"><?php echo $badgeText; ?></span>
                    </td>
                    <td data-label="<?php echo __('teacher.grade'); ?>">
                        <?php if ($submission['grade'] !== null): ?>
                            <strong style="color: var(--primary); font-size: 18px;"><?php echo $submission['grade']; ?></strong>
                        <?php else: ?>
                            <span style="color: var(--gray);">—</span>
                        <?php endif; ?>
                    </td>
                    <td data-label="<?php echo __('admin.actions'); ?>" class="actions">
                        <a href="/index.php?url=teacher/gradeSubmission/<?php echo $submission['id']; ?>" class="btn btn-small btn-primary">📝 <?php echo __('teacher.grade'); ?></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card">
        <div style="text-align: center; padding: 60px 20px;">
            <div style="font-size: 64px; margin-bottom: 20px;">📝</div>
            <h2 style="color: var(--gray); margin-bottom: 15px;"><?php echo __('teacher.no_submissions'); ?></h2>
            <p style="color: var(--gray);"><?php echo __('teacher.no_submissions_description'); ?></p>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>

