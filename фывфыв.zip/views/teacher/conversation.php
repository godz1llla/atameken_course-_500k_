<?php $title = __('messages.conversation_with'); include 'views/layouts/header.php'; ?>

<div class="container">
    <h1>💬 <?php echo __('messages.conversation_with'); ?> <?php echo $student['first_name'] . ' ' . $student['last_name']; ?></h1>
    
    <div class="messages-container">
        <?php foreach ($messages as $message): ?>
        <div class="message <?php echo $message['sender_id'] == Session::getUserId() ? 'sent' : 'received'; ?>">
            <div class="message-header">
                <strong><?php echo $message['sender_name']; ?></strong>
                <span class="message-time"><?php echo date('M d, H:i', strtotime($message['created_at'])); ?></span>
            </div>
            <p><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
        </div>
        <?php endforeach; ?>
    </div>
    
    <form id="messageForm" class="message-form" action="/index.php?url=teacher/sendMessage" method="POST">
        <input type="hidden" name="receiver_id" value="<?php echo $student['id']; ?>">
        <textarea name="message" placeholder="<?php echo __('messages.type_message'); ?>" required></textarea>
        <button type="submit" class="btn btn-primary">📤 <?php echo __('messages.send'); ?></button>
    </form>
</div>

<?php include 'views/layouts/footer.php'; ?>
