<?php $title = __('nav.courses'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>📚 <?php echo __('nav.courses'); ?></h1>
        <a href="/index.php?url=admin/createCourse" class="btn btn-primary">➕ <?php echo __('admin.create_course'); ?></a>
    </div>
    
    <table class="data-table">
        <thead>
            <tr>
                <th>ID</th>
                <th><?php echo __('course.title'); ?></th>
                <th><?php echo __('course.teacher'); ?></th>
                <th><?php echo __('admin.status'); ?></th>
                <th><?php echo __('admin.actions'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($courses as $course): ?>
            <tr>
                <td data-label="ID"><?php echo $course['id']; ?></td>
                <td data-label="<?php echo __('course.title'); ?>"><?php echo $course['title']; ?></td>
                <td data-label="<?php echo __('course.teacher'); ?>"><?php echo $course['teacher_name'] ?? 'N/A'; ?></td>
                <td data-label="<?php echo __('admin.status'); ?>">
                    <span class="status <?php echo $course['is_published'] ? 'active' : 'inactive'; ?>">
                        <?php echo $course['is_published'] ? __('course.published') : __('course.draft'); ?>
                    </span>
                </td>
                <td data-label="<?php echo __('admin.actions'); ?>" class="actions">
                    <a href="/index.php?url=admin/manageCourse/<?php echo $course['id']; ?>" class="btn btn-small">⚙️ <?php echo __('course.manage'); ?></a>
                    <a href="/index.php?url=admin/editCourse/<?php echo $course['id']; ?>" class="btn btn-small">📝 <?php echo __('common.edit'); ?></a>
                    <a href="/index.php?url=admin/deleteCourse/<?php echo $course['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('<?php echo __('common.confirm_delete'); ?>')">🗑️ <?php echo __('common.delete'); ?></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'views/layouts/footer.php'; ?>
