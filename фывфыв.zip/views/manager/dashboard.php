<?php $title = __('manager.dashboard'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <div>
            <h1>👋 <?php echo __('manager.welcome'); ?></h1>
            <p style="color: var(--gray); margin-top: 10px;"><?php echo __('manager.dashboard_description'); ?></p>
        </div>
    </div>
    
    <div class="stats-grid">
        <div class="stat-card">
            <h3>🎓 <?php echo __('dashboard.students'); ?></h3>
            <p class="stat-number"><?php echo $stats['total_students']; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>👨‍👩‍👧‍👦 <?php echo __('admin.groups'); ?></h3>
            <p class="stat-number"><?php echo $stats['total_groups']; ?></p>
        </div>
    </div>
    
    <div class="quick-links">
        <h2>⚡ <?php echo __('dashboard.quick_actions'); ?></h2>
        <a href="/index.php?url=manager/createUser" class="btn btn-primary">➕ <?php echo __('manager.add_student'); ?></a>
        <a href="/index.php?url=manager/createGroup" class="btn btn-primary">👨‍👩‍👧‍👦 <?php echo __('admin.create_group'); ?></a>
        <a href="/index.php?url=manager/users" class="btn btn-secondary">👥 <?php echo __('manager.view_students'); ?></a>
        <a href="/index.php?url=manager/groups" class="btn btn-secondary">👨‍👩‍👧‍👦 <?php echo __('admin.groups'); ?></a>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>

