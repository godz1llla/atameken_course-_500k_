<?php $title = $course['title']; include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="course-layout">
        <div class="course-sidebar">
            <h2><?php echo $course['title']; ?></h2>
            <div class="course-progress">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $progress; ?>%"></div>
                </div>
                <p><?php echo $progress; ?>% <?php echo __('course.progress'); ?></p>
            </div>
            
            <div class="course-modules">
                <?php foreach ($modules as $module): ?>
                <div class="module">
                    <h3><?php echo $module['title']; ?></h3>
                    <ul class="lessons-list">
                        <?php foreach ($module['lessons'] as $lesson): ?>
                        <li>
                            <a href="/index.php?url=student/lesson/<?php echo $lesson['id']; ?>" class="<?php echo $lesson['is_completed'] ? 'completed' : ''; ?>">
                                <?php echo $lesson['is_completed'] ? '✓ ' : ''; ?><?php echo $lesson['title']; ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="course-content">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 30px; flex-wrap: wrap; gap: 20px;">
                <div>
                    <h1><?php echo $course['title']; ?></h1>
                    <p><?php echo $course['description']; ?></p>
                </div>
                <?php if (isset($course['teacher_id'])): ?>
                <a href="/index.php?url=student/conversation/<?php echo $course['teacher_id']; ?>" class="btn btn-primary">
                    💬 <?php echo __('student.message_teacher'); ?>
                </a>
                <?php endif; ?>
            </div>
            
            <!-- Weekly Tests -->
            <?php if (!empty($weekly_tests)): ?>
            <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); padding: 30px; border-radius: 16px; margin: 30px 0; border-left: 5px solid var(--warning);">
                <h2 style="margin-bottom: 20px; font-weight: 900;">📅 <?php echo __('admin.weekly_tests'); ?></h2>
                <div style="display: grid; gap: 15px;">
                    <?php foreach ($weekly_tests as $wTest): ?>
                    <div style="background: white; padding: 20px; border-radius: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div style="flex: 1;">
                            <h4 style="font-weight: 800; margin-bottom: 8px;">
                                <?php echo __('admin.week'); ?> <?php echo $wTest['week_number']; ?>: <?php echo $wTest['title']; ?>
                                <?php if ($wTest['is_mandatory']): ?>
                                    <span style="background: #fee2e2; color: #991b1b; padding: 4px 12px; border-radius: 50px; font-size: 11px; margin-left: 10px;">⚠️ <?php echo __('admin.mandatory'); ?></span>
                                <?php endif; ?>
                            </h4>
                            <p style="color: #6b7280; font-size: 14px;"><?php echo $wTest['description']; ?></p>
                        </div>
                        <?php if ($wTest['is_passed']): ?>
                            <span class="status active">✅ <?php echo __('test.passed'); ?></span>
                        <?php else: ?>
                            <a href="/index.php?url=weeklyTest/take/<?php echo $wTest['id']; ?>" class="btn btn-warning">
                                📝 <?php echo __('lesson.take_test'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <?php if (!empty($mandatory_not_passed)): ?>
                <div style="margin-top: 20px; padding: 20px; background: rgba(239, 68, 68, 0.1); border-radius: 12px; border-left: 5px solid var(--danger);">
                    <strong>⚠️ <?php echo __('admin.attention'); ?>!</strong> 
                    <?php echo __('admin.mandatory_tests_remaining'); ?>: <?php echo count($mandatory_not_passed); ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>
