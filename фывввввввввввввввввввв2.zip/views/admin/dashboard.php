<?php $title = __('site_name'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <div>
            <h1>👋 <?php echo __('dashboard.welcome'); ?>, Admin!</h1>
            <p style="color: #6b7280; margin-top: 10px;"><?php echo __('dashboard.manage_platform'); ?></p>
        </div>
    </div>
    
    <div class="stats-grid">
        <div class="stat-card">
            <h3>👥 <?php echo __('dashboard.total_users'); ?></h3>
            <p class="stat-number"><?php echo $stats['total_users']; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>🎓 <?php echo __('dashboard.students'); ?></h3>
            <p class="stat-number"><?php echo $stats['total_students']; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>👨‍🏫 <?php echo __('dashboard.teachers'); ?></h3>
            <p class="stat-number"><?php echo $stats['total_teachers']; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>📚 <?php echo __('dashboard.courses'); ?></h3>
            <p class="stat-number"><?php echo $stats['total_courses']; ?></p>
        </div>
    </div>
    
    <div class="quick-links">
        <h2>⚡ <?php echo __('dashboard.quick_actions'); ?></h2>
        <a href="/index.php?url=admin/createUser" class="btn btn-primary">➕ <?php echo __('admin.create_user'); ?></a>
        <a href="/index.php?url=admin/createCourse" class="btn btn-primary">📖 <?php echo __('admin.create_course'); ?></a>
        <a href="/index.php?url=admin/createAchievement" class="btn btn-success">🏆 <?php echo __('admin.create_achievement'); ?></a>
        <a href="/index.php?url=admin/enrollments" class="btn btn-secondary">📝 <?php echo __('admin.manage_enrollments'); ?></a>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>
