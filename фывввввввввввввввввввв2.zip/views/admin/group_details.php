<?php $title = __('admin.group_members'); include 'views/layouts/header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h1>👥 <?php echo __('admin.group_members'); ?>: <?php echo htmlspecialchars($group['name']); ?></h1>
        <?php 
        $baseUrl = (isset($is_manager) && $is_manager) ? 'manager' : 'admin';
        ?>
        <a href="/index.php?url=<?php echo $baseUrl; ?>/groups" class="btn btn-outline">← <?php echo __('common.back'); ?></a>
    </div>
    
    <div style="display: grid; gap: 30px;">
        <!-- Первая карточка: Текущие участники -->
        <div class="card">
            <h2><?php echo __('admin.current_members'); ?></h2>
            
            <?php if (!empty($members)): ?>
            <table class="data-table" style="margin-top: 20px;">
                <thead>
                    <tr>
                        <th><?php echo __('auth.first_name'); ?></th>
                        <th><?php echo __('auth.email'); ?></th>
                        <th><?php echo __('admin.actions'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($members as $member): ?>
                    <tr>
                        <td data-label="<?php echo __('auth.first_name'); ?>">
                            <strong><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></strong>
                        </td>
                        <td data-label="<?php echo __('auth.email'); ?>">
                            <?php echo htmlspecialchars($member['email']); ?>
                        </td>
                        <td data-label="<?php echo __('admin.actions'); ?>" class="actions">
                            <form method="POST" style="display: inline-block;" onsubmit="return confirm('<?php echo __('common.confirm_delete'); ?>');">
                                <input type="hidden" name="action" value="remove_member">
                                <input type="hidden" name="student_id" value="<?php echo $member['student_id']; ?>">
                                <button type="submit" class="btn btn-small btn-danger">🗑️ <?php echo __('admin.remove_from_group'); ?></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div style="text-align: center; padding: 40px 20px;">
                <div style="font-size: 48px; margin-bottom: 15px;">👥</div>
                <p style="color: var(--gray);"><?php echo __('admin.no_members'); ?></p>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Вторая карточка: Добавить нового участника -->
        <div class="card">
            <h2><?php echo __('admin.add_new_member'); ?></h2>
            
            <?php if (!empty($nonMembers)): ?>
            <form method="POST" style="margin-top: 20px;">
                <input type="hidden" name="action" value="add_member">
                <div class="form-group">
                    <label><?php echo __('admin.select_student'); ?></label>
                    <select name="student_id" required>
                        <option value=""><?php echo __('admin.select_student'); ?></option>
                        <?php foreach ($nonMembers as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> (<?php echo htmlspecialchars($student['email']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">➕ <?php echo __('admin.add_to_group'); ?></button>
                </div>
            </form>
            <?php else: ?>
            <div style="text-align: center; padding: 40px 20px; margin-top: 20px;">
                <div style="font-size: 48px; margin-bottom: 15px;">✅</div>
                <p style="color: var(--gray);"><?php echo __('admin.no_students_available'); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>

