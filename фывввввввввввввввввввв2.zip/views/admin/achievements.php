<?php $title = __('nav.achievements'); include 'views/layouts/header.php'; ?>

<div class="container">
    <div class="page-header">
        <h1>🏆 <?php echo __('nav.achievements'); ?></h1>
        <a href="/index.php?url=admin/createAchievement" class="btn btn-primary">➕ <?php echo __('admin.create_achievement'); ?></a>
    </div>
    
    <div class="achievements-grid">
        <?php foreach ($achievements as $achievement): ?>
        <div class="achievement-card">
            <?php if ($achievement['icon']): ?>
                <img src="/public/uploads/<?php echo $achievement['icon']; ?>" alt="Achievement Icon">
            <?php else: ?>
                <div style="width: 120px; height: 120px; background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 60px; margin: 0 auto 20px;">🏆</div>
            <?php endif; ?>
            <h3><?php echo $achievement['title']; ?></h3>
            <p><?php echo $achievement['description']; ?></p>
            <p class="condition">📋 Type: <?php echo $achievement['condition_type']; ?></p>
            <p class="condition">🎯 Value: <?php echo $achievement['condition_value']; ?></p>
            <a href="/index.php?url=admin/deleteAchievement/<?php echo $achievement['id']; ?>" class="btn btn-danger btn-small" onclick="return confirm('<?php echo __('common.confirm_delete'); ?>')">
                🗑️ <?php echo __('common.delete'); ?>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>
