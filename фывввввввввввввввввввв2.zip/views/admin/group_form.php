<?php 
$isEdit = isset($group);
$title = $isEdit ? __('admin.edit_group') : __('admin.create_group'); 
include 'views/layouts/header.php'; 
?>

<div class="content-area">
    <div class="card">
        <h1><?php echo $isEdit ? '📝 ' . __('admin.edit_group') : '➕ ' . __('admin.create_group'); ?></h1>
        
        <form method="POST" class="form" style="margin-top: 30px;">
            <div class="form-group">
                <label><?php echo __('admin.group_name'); ?></label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($group['name'] ?? ''); ?>" required placeholder="<?php echo __('admin.group_name'); ?>" maxlength="255">
            </div>
            
            <div class="form-group">
                <label><?php echo __('course.title'); ?></label>
                <select name="course_id" required>
                    <option value=""><?php echo __('admin.select_course'); ?></option>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?php echo $course['id']; ?>" <?php echo (isset($group) && $group['course_id'] == $course['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($course['title']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label><?php echo __('course.teacher'); ?></label>
                <select name="teacher_id">
                    <option value=""><?php echo __('admin.select_teacher'); ?></option>
                    <?php if (!empty($teachers)): ?>
                        <?php foreach ($teachers as $teacher): ?>
                            <option value="<?php echo $teacher['id']; ?>" <?php echo (isset($group) && $group['teacher_id'] == $teacher['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?> (<?php echo htmlspecialchars($teacher['email']); ?>)
                            </option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option value="" disabled><?php echo __('admin.no_teacher'); ?></option>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-success">💾 <?php echo __('common.save'); ?></button>
                <?php 
                $baseUrl = (isset($is_manager) && $is_manager) ? 'manager' : 'admin';
                ?>
                <a href="/index.php?url=<?php echo $baseUrl; ?>/groups" class="btn btn-outline">❌ <?php echo __('common.cancel'); ?></a>
            </div>
        </form>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>

